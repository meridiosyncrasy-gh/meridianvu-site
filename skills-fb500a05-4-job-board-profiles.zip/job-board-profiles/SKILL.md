---
name: "job-board-profiles"
description: "Step 4 of 7 in the job search skill set, after portfolio-builder and before job-screening. Optimizes the person's profiles on LinkedIn, Indeed, ZipRecruiter and Upwork from their Career Profile, resume versions and portfolio pieces, so recruiters and search filters find them for the right tracks. Writes headlines, About sections, skills, job preferences, pay, featured work and Upwork rate, with a ChatGPT recruiter review of all copy. Syncs the profile photo and makes a LinkedIn banner with ChatGPT from the brand kit or portfolio branding. Updates through connectors where they can write and the browser where they cannot. Runs a consistency check so titles, dates and numbers match the resume and proof bank on every site. Every live change is shown before it publishes. Use for \"update my LinkedIn\", \"optimize my Upwork profile\", \"sync my job site profiles\", \"make a LinkedIn banner\", \"what should my Upwork rate be\", or after a new resume or portfolio version. Works for any person and field."
---

# Job Board Profiles

Step 4 of 7 in the job search skill set: career-goal-mapping, resume-builder, portfolio-builder, **job-board-profiles**, job-screening, application-writer, interview-prep-follow-up. Run it after a resume or portfolio update and before screening, because recruiters and board search filters read these profiles first.

## Core rule: no long dashes (applies to every person)

Everything this skill writes follows it: headlines, About and overview text, skills, the copy pack and messages to the person.

- Never use the em dash (—) or the en dash (–). The plain hyphen is fine inside words like "full-time".
- Rewrite instead of swapping: two ideas become two sentences, a label and detail use a colon, side-by-side items use a vertical bar ("Designer | Acme Co"), ranges use "to".
- Before showing, saving or publishing anything, search it for "—", "–", "&mdash;", "&ndash;", "&#8212;" and "&#8211;". The count must be zero.

Other style rules come from the Voice Rules in the Career Profile.

## Before you start

1. **Career Profile:** tracks and target titles, money floor and "will not apply under", guardrails, Proof Bank, Skills, Voice Rules, internal-only terms, Asset Library. Search for it in Drive, Notion and artifacts, and in the person's other accounts if they use more than one. If it truly is missing, rebuild what you need from the newest resume versions and portfolio site (they carry the proof bank numbers), ask only for what they cannot give (lead track, pay floor, work type), and suggest career-goal-mapping afterwards.
2. **Resume versions** from resume-builder. The profiles must match them: same titles, dates, employers and numbers.
3. **Portfolio pieces** from portfolio-builder, and which track each one proves.
4. **What is live now:** read each current profile (connector where it can read, browser otherwise) and build the section inventory below before writing anything. Read in the browser the person is signed into; a fresh browser hits sign-in walls and bot checks. Profiles may already be partly updated, so fix mismatches rather than pasting over work that is already right.
5. **Work type:** full-time salary, contract or freelance. It decides job type settings and which pay unit each site gets (see Pay settings).

## Every section, every platform (the core job)

A run is never just the headline and summary. On every platform, open every section the site has and mark each one Current, Stale, Empty or Not used:

- **Stale:** old numbers, old titles, dates that differ from the resume, buzzword copy, typos, missing links. Rewrite it.
- **Empty:** treat it as free search and trust space. Fill it from the proof bank, resume, portfolio and Asset Library (honors, side projects, free resources, past businesses, certifications, volunteer work). Skip it only when there is truly nothing real to put there.
- **Portfolio or featured work:** sync it every run (see Portfolio sync).
- **Resume roles missing from the profile:** add them. Roles on the profile that are missing from the resume stay, but rewrite them in the same plain voice.

Keep the inventory as a checklist in the copy pack so the person can see every section was touched.

## Back up, then remove what weakens the profile

Old entries can hurt more than an empty section. Judge every existing entry (projects, roles, media, skills, services, featured items) against the lead tracks.

- **Keep** what proves a lead track, shows a real result, is recent, or fills a gap nothing newer covers. Rewrite it if it is only stale.
- **Remove** what weakens: outdated tools or tactics (follower bots, dead platforms), off-track work that crowds out the tracks, entries that duplicate an experience role, unprofessional or keyword-stuffed wording, and dates that conflict with the resume.
- **Back up first, every time.** Save the full text, dates, skills, links and any media of each entry before deleting it, in the person's job search folder (the one recorded in the Career Profile Asset Library at setup), under `_Archive/Profile Backups/[Site] [Section] | removed [date]`. Expand every "see more" so nothing is cut off. When media cannot be downloaded, show each item at full size on its own and screenshot it. Write a short notes file listing what each media item was.
- Once the backup is saved and checked, delete without asking. Say what was removed and where the backup lives in the final summary.
- **No job search folder yet** (a person just starting their career): suggest one, for example a "Job Search" folder in their Google Drive with Resumes, Applications, Cover Letters, Portfolio and Archive subfolders. Create it, record its path in the Career Profile Asset Library, then save the backup there.

## ChatGPT copy pass (every run, before anything goes live)

Claude drafts, ChatGPT reviews as a recruiter, Claude judges. Same pattern as resume-builder and portfolio-builder.

1. Claude drafts every changed field (headlines, About, summaries, experience and education text, Featured descriptions, top skills) from the proof bank.
2. Open ChatGPT in a Temporary chat (`chatgpt.com/?temporary-chat=true`) so memory and personalization stay out. Paste one prompt with all drafts, labeled by site and field, with character limits.
3. The prompt sets the role (a recruiter or client who hires for the lead track) and the rules: no new facts or numbers, every number kept exactly, no em or en dashes, plain human words, no buzzwords. For each field ask for one line on what a recruiter thinks, then an exact replacement or KEEP, and the 3 most important changes overall.
4. Claude judges each suggestion: keep what is clearer and still true, reject anything that adds claims, merges stats or breaks the Voice Rules. Then run the dash and truth checks again.
5. Composer tip: a typed newline sends the message, so insert multi-line prompts with `document.execCommand('insertText')` on the prompt box.

## Profile photo (every platform with one)

- First note whether each headshot is a real, unedited photo or AI-made or AI-edited, and record it in the Asset Library.
- **Upwork only takes a real, unaltered photo of the person.** Its photo rules ban digitally altered images, and an AI headshot puts the account at risk. Never put an AI-made or AI-edited headshot on Upwork. Keep the real photo already there, and if no real photo is on file, ask the person for one.
- On other sites, use the portfolio headshot (or the Asset Library's) so the person looks the same everywhere, unless that site's photo rules also require a real, unedited photo. Read each site's photo rules before uploading. Skip a site that already matches.
- Before replacing any photo, save a copy of the current one (download it or save its image URL) so it can be put back.
- Crop to head and shoulders, centered. Never leave text or overlays on the face.
- Upload by fetching the image in the page when the site allows it (convert WebP to JPG on a canvas). If the site's security blocks the fetch, stage the image full screen in a tab, screenshot it, and upload that screenshot to the file input.

## LinkedIn banner (ChatGPT designs, Claude checks)

1. Brand source: the person's brand kit. If there is none, use the portfolio site's colors, fonts and motifs.
2. Brief to ChatGPT: 1584 x 396 (4:1), left 30% kept clear for the profile photo, all text inside the center 1350 px, exact wording supplied (name line, track title, one proof line, portfolio URL), brand colors and fonts, no stock faces, no solid overlays.
3. Ask ChatGPT to critique its own draft as a designer and make a second version.
4. Claude checks spelling, stray punctuation, orphans and widows, and that text stays clear of the photo area.
5. If the image is not 4:1, pad it on a canvas with its own background color until it is, so LinkedIn's centered crop keeps everything.
6. Upload: stage it full width on a matching background, screenshot it, and send it to the banner's "Upload" file input (not the stock cover picker). Confirm "Saved" and view the profile with the photo on top.

## Which track each profile leads with

One profile cannot sell every track. Decide per site and confirm with the person once, then save it to the Career Profile:

- **LinkedIn, Indeed, ZipRecruiter:** lead with Track 1 or Track 2 (whichever brings income soonest if they need it fast). Other tracks show up in skills and experience, not the headline.
- **Upwork:** lead with Track 3 (side work). Use extra specialized profiles for other tracks only if the account offers them.

## Pay settings

Set the floor in the unit each site uses, and never under "will not apply under".

- Salary seekers: yearly floor everywhere.
- Contract and freelance: hourly floor. Where a site only takes yearly pay, use hourly x 2,080 and tell the person.
- Match job types to the work type (contract, temporary, part-time for contract seekers) and remove the rest.

## Platform by platform

Tool names change, so go by each tool's description.

### LinkedIn (browser, no connector)

Write a copy pack, ready to paste:

- **Headline:** under 220 characters. Target title in the words job posts use, the core skill set, one proof number or result.
- **About:** first person, 3 short paragraphs. The first two lines carry the hook, since they show before "see more". End with what they want next and how to reach them.
- **Experience:** top 3 bullets per role, taken from the matching resume version.
- **Skills:** pin the top skills that match the lead track's keywords.
- **Featured:** portfolio home plus the best case studies for the lead track, in proof order (see Portfolio sync).
- **Projects, Honors and awards, Licenses and certifications, Volunteer, Services:** fill each from the proof bank and Asset Library, or mark it not used.
- **Job preferences:** target titles, remote or location settings, start date.
- **Open to Work:** recruiters only vs public banner is the person's choice. Mention that a current employer can see the public banner.
- **Custom URL and contact info:** clean URL and the portfolio link.

When the person asks for the profile to be updated, fill the approved copy in the browser one field at a time and save each one, then verify it on the page. Otherwise give the copy pack to paste. Never automate anything beyond editing their own profile (no bulk actions, connection requests or messages): LinkedIn's User Agreement bans bots and can restrict the account.

### Indeed

- The connector reads the live resume (`get_resume`) but cannot write. Compare it with the current track version.
- In the browser at the person's Indeed profile: upload the new resume PDF, set job titles, job types, minimum pay with its pay period, remote and city-level location, and the "ready to work" setting if they want it.
- Work areas are a fixed list. Skip an option that only loosely matches (a tech support area pulls help desk jobs for an automation track).
- Also update the summary, skills, certifications and links (portfolio home plus the top case studies).

### ZipRecruiter

- Check the connector's connection status. If it is not linked, start the connect flow; the person signs in themselves, then confirm the status.
- ZipRecruiter holds a full profile, not just settings: headline, executive summary, objective, work history, achievements, skills, links and minimum pay. Treat it like LinkedIn content and run every section through the consistency check, since old numbers hide here.
- In the browser: upload the resume, rewrite those sections from the lead track's resume version, set location, pay (yearly only), industry and remote, and add job alerts for each track's titles.

### Upwork (connector can write)

- Read the live profile through the connector. Rate insights only run on a Client account: use the person's client account if they have one, otherwise judge the rate from comparable job posts.
- **Title:** a specific niche for Track 3, not a general label.
- **Overview:** open with the client's problem and the result they get, then proof bank stories with numbers, then how working together goes. The first two lines show in search, so they carry the hook.
- **Hourly rate:** compare the rate insights with the track's rate and the money floor. Suggest a number and say why. Never go under the floor.
- **Skills:** match the words clients use in job posts for the track.
- **Portfolio:** synced with the portfolio site every run (see Portfolio sync).
- **Employment history and education:** match the resume, including each entry's dates and description, where old numbers and buzzword copy often linger. Add resume roles that are missing (an independent or freelance practice counts). End each entry with a link to its case study when one exists.
- **Other experiences:** never leave it empty. Add honors, side projects built with the person's core skills, free resources they publish and past businesses, each with a result and a link.
- **Also check:** availability and hours, project length preference, languages, certifications and video introduction.
- **Project Catalog:** see Upwork Project Catalog offers below.
- Show every change, then publish through the connector after a clear yes.
- Connector behavior: each write returns a preview to confirm. A new employment preview cancels any unconfirmed one, so preview and confirm employment edits one at a time. Skill names resolve loosely, so read the resolved list in the preview and swap any wrong match before confirming.
- Other experiences (add, update, remove) are in the connector.
- Rate, profile visibility, location, project length and portfolio items are not in the connector: change them in the browser. Location needs a full street address (ask which one) and may trigger a security question only the person can answer.

## Upwork Project Catalog offers (when the person says yes)

Catalog projects are fixed-price offers clients buy without a proposal. Use them as the first rung of the person's value ladder: small, low-risk purchases that build Upwork reviews and lead to their bigger services.

1. **Read the ladder.** Pull the services and packages from the portfolio site (portfolio-builder output) or the Career Profile, with their prices. If the site's offers are large, the catalog needs smaller entry offers. If the site has small offers, reuse them as projects.
2. **Check demand.** Search Upwork job posts for each track (connector, fixed-price, verified payment) and note the small jobs that keep coming up, their budgets and proposal counts. job-screening's demand notes count too.
3. **Design 2 to 4 offers.** Each one must: match an ask clients post often, be provable with a proof bank story, finish in days, sit at an earlier stage of the customer journey than a website service, and end with a natural next step to that service. Good patterns: a quick win on a few items (10 listings), an audit with a ranked fix list, a single working build (one automation). Give 3 tiers with a clear scope boundary in each (counts, pages, what is excluded), delivery days and revisions. Price the top tier near the person's smallest website offer and keep every tier at or above the money floor's spirit: a lower price is fine only for genuinely small, fast work.
4. **ChatGPT pass.** Send all offers in one Temporary chat as an Upwork buyer and catalog expert: what a buyer thinks, exact replacements, pricing flags. Keep claims as past results, not promises. Claude judges each change.
5. **Build in the browser** (the connector cannot create projects): Overview (title after the fixed "You will get" prefix, max 75 characters and at least 7 words, category, required attributes, 5 tags), Pricing (tier titles max 30 characters, tier descriptions max 80, days, counts, options, prices, an add-on when it fits), Gallery (JPG or PNG under 4,000 px, 4:3 at about 1600 x 1200, real work from the portfolio, no URLs, contact info or Upwork logos in the image, cover set on the clearest one), Requirements (2 or 3 questions: access, scope, goals), Description (summary max 1,200 characters, 3 steps, 1 or 2 FAQs), then Submit for Review.
6. Log each project with its link, tiers and the website service it leads to in the Asset Library, and mention it in the final summary.

Builder tips: tag inputs need a real click (sometimes two) before typing, and Enter saves a typed tag. Some checkboxes only stick with a real click on the box itself; read `.checked` back after clicking. Required attribute groups show "At least one option must be chosen" only after Save, so read the error and fix that group.

## Portfolio sync (every platform that shows work)

Pull every piece from the portfolio site (portfolio-builder output) and compare it with what each platform shows: Upwork portfolio, LinkedIn Featured and Projects, ZipRecruiter and Indeed links.

- Each piece gets a specific title with its result (Upwork titles max 70 characters), a short description in the site's own words with the numbers from the proof bank, a link to its page, the site's cover image plus 2 or 3 images from the page, and skills from the person's skill list.
- Order: lead track proof first, then brand or design range. Pieces that only show older work go last.
- Replace generic or stale pieces once the new ones are live. Delete old ones only after the person approves the swap.
- Upwork portfolio (browser): images must be JPG or PNG under 4,000 x 4,000 px, so convert WebP and scale tall screenshots before upload. The thumbnail crops to 4:3, so upload a 4:3 version of the cover (pad a wide cover with its own background color) as the thumbnail. The newest published piece shows first, so publish in reverse order or reorder after. Skills only stick when an option in the dropdown is clicked with a real click, and text fields need real typing, not scripted values.

## Browser tips

- Rich text boxes (LinkedIn, ZipRecruiter) ignore direct form filling. Click inside the actual text first (clicking the container and pressing select all grabs the whole page), select all with the platform shortcut (cmd on Mac), delete, then type the full text. Never place the cursor by pixel to insert a word.
- Typing can drop characters on LinkedIn. Read the saved text back every time. Plain textareas and inputs take `document.execCommand('insertText')`, which does not drop characters.
- Native file dialogs: before clicking an upload button, patch `HTMLInputElement.prototype.click` so file inputs are captured instead of opening the picker, then set the file with a DataTransfer.
- Chip lists (ZipRecruiter skills): remove chips one at a time and screenshot between, since chips reflow after each removal. Add new ones with the Add button; Enter can submit the whole form.
- A site that logs the person out mid-run (Upwork can after a photo change) is a stop for that site: list it under Open Tasks and keep going on the others.
- Escape or an X often closes a modal without saving. Save first, then confirm the saved text on the page.
- Close stray popups (message windows, upsells, "people you may know") without acting on them.
- Resume uploads: the browser cannot drive the computer's file picker. If the resume PDF is hosted somewhere the page can fetch (a portfolio site on GitHub Pages allows this), fetch it in the page, build a File, and hand it to the upload input with a DataTransfer, intercepting the input's click so no native dialog opens. Otherwise use computer use with the file in a connected folder, or ask the person to do that one upload.

## Consistency check (every run)

Across all four sites plus the resume:

- Titles, employers, dates and numbers match the proof bank and resume exactly. No merged stats, nothing from "Learning now" claimed as mastered.
- No internal-only terms, no banned phrases.
- No full street address, birth date or ID numbers. Phone visibility is the person's choice.
- Portfolio and LinkedIn links open and work, and every portfolio piece on every platform links to its live page with numbers that match it.
- The portfolio site's own numbers match too; a site can show two values for one stat.

## Approval

Profile changes are public and carry the person's name, so they are always shown before publishing, at every autonomy level. Show the full set of changes once, as one list. When the person approves it, or their request already asks for the profiles to be updated, publish everything without stopping to ask again for each item. Removing entries that weaken the profile needs no extra yes once the backup is saved (see Back up, then remove). Deleting work that still strengthens the profile, such as a current portfolio piece or an on-track role, needs a clear yes.

## Save and log

- Save the copy pack as a doc named `Job Board Profiles | [date]`.
- Add or update each profile's row in the Career Profile Asset Library (site, link, lead track, last updated), and add a Change Log line.

## When to re-run

- After any new resume version or portfolio piece.
- After a new proof bank win.
- Monthly for the Upwork rate insights.
- When job-screening keeps finding the wrong kind of jobs, or recruiters reach out for roles off track.

## When done

Say in plain words what changed live on each site, section by section, show the banner, link the copy pack, and list under **Open Tasks** only the steps the person must do themselves (sign-ins, uploads that need their computer, prices for catalog offers, conflicts only they can settle).