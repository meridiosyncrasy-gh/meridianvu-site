---
name: "application-writer"
description: "Step 5 of the job search skill set. Writes and sends job applications in the person's own voice using their Career Profile: cover letters, form question answers and short recruiter messages. Then it fills the application in the browser and keeps an application log. Two modes: Review mode (default for new users) where Claude fills everything and stops so the person checks and clicks submit, and Auto mode (for confident users who turn it on) where Claude submits after the person approves the list of jobs in chat. Use for \"write a cover letter\", \"apply to this job\", \"answer these application questions\", \"apply to my Apply list\", \"log this application\", or \"what have I applied to\". Pairs with job-screening. Works for any person and field."
---

# Application Writer

Part of a six skill job search set (career-goal-mapping, resume-builder, portfolio-builder, job-screening, application-writer, interview-prep-follow-up).

## Core rule: no long dashes (applies to every person)

This rule is part of the job search skill set and does not change per person. Everything this skill writes follows it: cover letters, form answers, recruiter messages, file names, the application log, and the messages Claude sends the person.

- Never use the em dash (—) or the en dash (–). The plain hyphen (-) is fine inside words like "full-time" or "30-60-90".
- Rewrite instead of swapping one dash for another:
  - Two related ideas become two separate sentences.
  - A label and its detail use a colon ("Pay: $85K to $95K").
  - Side-by-side items, or a title and a name, use a vertical bar ("Designer | Acme Co").
  - Ranges use "to" ("Jan 2024 to Mar 2026", "$78K to $96K").
- Text pulled from job posts, old resumes, templates, ChatGPT or any other tool gets rewritten the same way before it goes into anything this skill makes. Direct quotes from a job post on a screening card are the only exception.
- Before showing, saving or sending anything, search it for "—", "–", "&mdash;", "&ndash;", "&#8212;" and "&#8211;". The count must be zero.

The person's other style preferences (words to avoid, tone, greetings) come from the Voice Rules in their Career Profile and change per person.

## Before you start

1. Read the **Career Profile** (`career-profile.md` in the Claude project). If missing, run **career-goal-mapping** first. Pay close attention to Voice Rules, the Proof Bank, and Submit Mode.
2. Read `application-log.md`. If the job is already there, stop and tell the person.
3. Get the job's screening card. If there is none, run **job-screening** Mode A on the job first. Never apply to a job marked Skip unless the person says to.

## Cover letter structure

About 250 to 380 words, 4 to 5 short paragraphs.

1. **Greeting:** "To the [Company] Team," unless the Voice Rules say otherwise. Use a hiring manager's name only if it is in the post.
2. **Hook:** passion for the industry or the problem the company solves, plus who the person is in one line. Show love for the industry, not fan talk about the company itself.
3. **Main proof:** the proof bank win that best matches the job's top duty, told as a mini story with its number. End with one sentence linking it to what the company needs.
4. **Second proof:** a different side of them (side project, personal brand, earlier role) that matches another duty. Add one line on how they think or work.
5. **Optional range paragraph:** only for roles that want breadth.
6. **Close:** forward-looking fit, echo one phrase from the company's own values or post, and a light call to talk. No begging, no salesy push.
7. **Sign off:** "Best," or "Best regards," then name, email, phone (optional).
8. **Links under the signature:** 1 to 3 labeled links (the featured portfolio piece, the matching case study, the portfolio home).

Tone: follow the Voice Rules. Default is warm, plain and personal, like the person talking. Passion industries get extra personality. Corporate roles get a bit more polish but still sound human.

## Form question answers

- Answer in first person, 80 to 180 words unless the form sets a limit. Count and stay under limits.
- "Why this company / role": industry passion + one matching proof + what they want to build there.
- "Tell us about a project": a short STAR story (situation, task, action, result with number).
- Salary fields: use the "safe for the form" number from the screening card.
- "How did you hear about us": the true source.
- Yes or no eligibility questions (work authorization, location, schedule): answer only from the Career Profile. If unknown, ask the person. Never guess.
- Demographic and voluntary disclosure questions: always leave for the person, or pick "decline to answer" only if they told you to.

## Truth and voice check (before showing anything)

- Every number and claim is in the proof bank, with its locked wording.
- No merged stats, no skills they are still learning claimed as mastered.
- No em dashes or en dashes (core rule). None of their banned phrases or punctuation. Internal-only terms never appear.
- No generic filler ("I am writing to express my interest", "fast-paced environment", "team player").
- The company name and job title are right everywhere (no leftovers from another letter).

## Files

- Save each cover letter as a Google Doc or Claude Doc, and a PDF named `[Job Title] | [Company] Cover Letter`.
- Keep a copy of every form answer in the log entry so they can be reused for interviews.

## Applying in the browser

Use the browser the session offers. Sign in with the person's Google option if a login is needed. Never type passwords, never create accounts for them, never solve CAPTCHAs. If a site needs a new account, a password, or a "verify you are human" box, ask the person to do that one step, then continue.

Upload the right resume version and cover letter PDF. Fill every field from the Career Profile and the drafts above.

### Review mode (default)

For new users, or whenever Submit Mode in the profile says Review:

1. Fill the whole application.
2. Stop on the final page before submit.
3. Tell the person: the job, the resume and letter used, the salary entered, and any field you were unsure about.
4. They review and click submit themselves. Then log it.

### Auto mode (confident users only)

Only when the Career Profile Submit Mode says Auto **and** the person asks to apply in this chat:

1. Show the batch first: a list of every job you will submit (title, company, link, resume version, salary number). One message.
2. Wait for a clear yes in chat for that batch. A yes covers only the jobs on that list.
3. Submit each one. If anything unexpected comes up (a new required question, an assessment, a fee, a request for ID or bank details, an account to create), skip that job and report it instead of guessing.
4. Log every submission with the confirmation screen text or email.

Suggest people stay in Review mode for their first 10 or so applications, then switch once the letters sound right to them.

## Application log

Keep `application-log.md` in the Claude project (or a Google Sheet if the person prefers). Template:

```markdown
# Application Log

| Date | Company | Role | Link | Source | Track | Posted pay | Pay I entered | Resume used | Portfolio piece | Cover letter | Status | Next step and date | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
```

Status values: Screened: Skip, Drafted, Applied, Recruiter screen, Interview, Final round, Offer, Accepted, Rejected, Withdrawn, Ghosted.

After applying, set a next step: check back in 7 to 10 days (interview-prep-follow-up writes the follow up). When asked "what have I applied to", summarize the log by status and flag anything waiting longer than 2 weeks.

## When done

Tell the person in plain words what was sent or drafted, where the files are, and what happens next. Attach or link the actual cover letter.