---
name: interview-prep-follow-up
description: Step 6 of the job search skill set. Gets a person ready for every stage after applying, using their Career Profile and application log. Builds a company research pack and a one page interview cheat sheet (company talking points, proof stories tagged to the company's values, how-I-think story, questions to ask that test the No list), STAR answers, a 30-60-90 day plan, pay talk scripts with a walk-away line, and follow up emails - thank you notes, checking in when it goes quiet, replies to rejections, offer replies, and asking to keep contacts as references when a contract ends. Drafts emails in Gmail but never sends without a yes. Use for "prep me for my interview", "I got an interview with [company]", "write a thank you email", "they ghosted me", "how do I negotiate this offer", or "my contract ended". Works for any person and field.
---

# Interview Prep and Follow Up

Part of a six skill job search set (career-goal-mapping, resume-builder, portfolio-builder, job-screening, application-writer, interview-prep-follow-up).

## Before you start

1. Read the **Career Profile** and the job's row in `application-log.md` (resume used, letter sent, pay entered, form answers). Answers in the interview must match what was sent.
2. Find the interview details: Gmail and Google Calendar connectors if available (search the company name), or ask the person for the date, time, format, length and who they meet.

## Step 1: Company research pack

Gather and keep it in one doc (Claude Doc or project doc named `[Company] Interview Pack`):

- The job post and anything the company sent (prep emails, culture videos, decks). Videos: get the transcript.
- Indeed connector `get_company_data`: ratings, review themes, interview process notes, salaries for the title.
- Company site: what they sell, who they serve, their stated values and the exact words they use for them.
- Recent news, funding, size, leadership.
- The interviewer(s): role and background if public.
- Their lingo: terms, frameworks or slogans they use. The person should use these naturally.

## Step 2: The cheat sheet (one page, made to scan during a call)

```markdown
# [Company] | [Round] | [Date and time]
Who: [names and roles]   Length: [__ min]   Format: [video/phone]

## 1. Their words to use
- [value or term]: what it means to them

## 2. My proof, tagged to their values
- [Story name] (Value: ___): one line situation, one line action, one line result with number

## 3. How I think (one story in their framework, or Problem / What I decided / What happened / Why that points here)

## 4. Why me, why now (3 bullets, plain words)

## 5. Questions I will ask
- [Tests a No list item, asked kindly]
- [What a win looks like at 90 days]
- [Team, tools, how work gets reviewed]
- [Next steps and timeline]

## 6. Pay
- Number already entered on the form: $___
- Aim for: $___   Walk away under: $___

## 7. Logistics
- Link, test camera, notes open, water, quiet room
```

## Step 3: Answers and extras

- **STAR stories:** 5 to 7 stories from the proof bank that cover common questions (a big win, a failure and fix, conflict, leading without authority, juggling deadlines, learning something fast, a process they built). Same numbers as the resume.
- **Tell me about yourself:** 60 to 90 seconds. Now, before, next.
- **Frustrations or why leaving:** honest but positive. Frame as wanting more room to do X.
- **30-60-90 day plan:** for second rounds and senior roles. 30 days learn, 60 days improve one thing, 90 days own a result. Use the company's own goals.
- **Take home or presentation tasks:** help plan, build visuals as artifacts or slides, and rehearse. Keep the person's own thinking at the center.
- **Video interviews with a time limit:** short bullet answers they can glance at, timed to fit.
- Offer a mock interview: Claude asks questions one at a time and gives feedback after each answer.

## Step 4: Pay talks

- Let them name a range first when possible. If pushed, use the "aim for" number with a range starting near it.
- Talk total pay: base, bonus, benefits, PTO, equipment, remote stipend, contract length, rate for 1099 (add 20 to 30 percent over a W2 hourly to cover taxes and no benefits).
- If the real number is far below the floor, draft a polite walk-away: thank them, state the number that would work, leave the door open.
- Never accept or decline for them. Give the script, they decide.

## Step 5: Follow up emails

Draft in Gmail (connector `create_draft`) or in chat. **Never send without the person's clear yes for that exact email.** Use the Voice Rules.

- **Thank you (same day):** 3 to 5 sentences. Thank them, call back one specific thing discussed, one line on fit, sign off.
- **Gone quiet (7 to 10 business days after the expected reply):** short, friendly, asks for an update and restates interest.
- **Second nudge (another 7 to 10 days):** shorter. Then mark Ghosted in the log and move on.
- **Rejection reply:** thank them, ask to be kept in mind, optionally ask for one piece of feedback. Keeps the door open.
- **Offer reply:** thank them, confirm details in writing, ask for time to review if needed, or counter using Step 4.
- **Contract ended:** thank them, wrap up any loose work by a set time, ask to be kept in mind for other work, and ask permission to list one or two contacts as references.

## Step 6: Update everything

- Update the application log status and next step date after every stage.
- New wins or stories that came up in prep go into the Career Profile proof bank.
- After a final outcome, add one line to the log's Notes on what worked or what to change.

## When done

Give the cheat sheet (or the drafted email) and one plain line on what happens next. Attach or link the actual doc.
