---
name: portfolio-builder
description: "Step 3 of the job search skill set. Turns a person's real work into proof employers can see: case studies, track-specific portfolio versions, and a portfolio website hosted free on GitHub Pages or as Claude artifacts. Also plans and builds spec projects (made-up brands built to fill a portfolio gap or win one job) using HTML mockups, AI images and optional Shopify dev stores. Also runs revision rounds on an existing portfolio site against a built-in quality bar. Exports PDFs for job forms. Use for \"build my portfolio\", \"write a case study\", \"make a portfolio site\", \"fix up my portfolio site\", \"I have no proof for this kind of role\", \"make a spec project for this job\", \"update my portfolio for [track]\", or \"export my portfolio to PDF\". Reads the Career Profile. Works for any person and field."
---

# Portfolio Builder

Part of a six skill job search set (career-goal-mapping, resume-builder, portfolio-builder, job-screening, application-writer, interview-prep-follow-up).

## Before you start

1. Read the **Career Profile** (`career-profile.md` in the Claude project). If missing, run **career-goal-mapping** first.
2. Inventory existing work: old portfolios (PDF, Slides, Canva, Behance), case studies, live links, Drive folders of assets, videos. Read or look at all of it.
3. Map work to tracks: for each track in the profile, list which pieces prove it and which tracks have **no proof yet**. Show this map to the person. A track with no proof needs a case study from real work or a spec project.
4. Collect the **locked facts** before writing a word: numbers from the proof bank, which accounts are personal vs brand, which projects are paid clients vs concepts, how the person was engaged (employee, contractor, own business name), and who may be named. Ask once and save the answers to the Career Profile.

## The portfolio system

- **Case studies:** deep proof for one project. 1 to 6 pages. The strongest thing to link in an application.
- **Mini case studies:** one slice of a big case study (example: just the AI image pipeline from a bigger store build). Fast to make, very targeted.
- **Track portfolios:** a curated set of pieces per track. Make variants by reordering and trimming sections, not by rewriting everything.
- **Portfolio home:** one website that holds it all, with a page or anchor per track.
- **Spec projects:** made-up but fully executed projects that prove a skill there is no paid work for yet.

## Case study template

Use this shape. It reads like a story, not a report:

1. **The Big Idea:** one or two sentences on what was built and why it matters.
2. **The Real Problem:** what was broken or missing before, in plain words.
3. **What I Built:** the system, steps, tools, and decisions. Include visuals: before and after, screenshots, process diagrams.
4. **The Result:** numbers from the proof bank (time saved, output volume, growth, sales). Only proof bank numbers.
5. **What This Proves for You:** one short paragraph tying it to what the target employer needs.
6. **Proof links:** live site, SOP docs, video walkthrough (Loom or similar), asset folders.

Header block: title, subtitle with the client or brand, byline with name and the track title, then "Platform" and "Goal" lines. End with a short first person contact block.

## Portfolio rules that work

- Bio and all copy in **first person**. Never third person.
- Do not open with "thank you for considering me". Open with who you are and what you do. Put the call to action on the **last page only**.
- One benefit sentence per piece, written to the reader ("decks that help your team win the room").
- Label visuals so a skimmer gets it in 3 seconds.
- Specialize per track. Cutting good but off-topic work makes the portfolio stronger.
- For pure design roles, swap marketing jargon (funnel, conversion, growth) for design words (UI, visual system, asset creation). For marketing roles, do the reverse and lead with numbers.
- Be honest about AI and tools. Say what was AI assisted. Many employers want to see it.
- Check every link works before exporting.

## Building the portfolio home

Pick what fits the person, in this order:

1. **Claude artifacts (fastest):** each case study as an HTML artifact page, plus a hub page linking them. Private until they share. Good for quick links in applications.
2. **GitHub Pages (free, real web address):** a static site in a repo, auto published. Steps:
   - Person creates a free GitHub account (sign in with Google if offered).
   - Create a repo named `[username].github.io` for a main site, or any name for a project site.
   - Claude writes the site files (index.html, one page per case study, an assets folder). Push with the `gh` command line tool if signed in, or upload through the GitHub web page in the browser (up to about 40 files and under 10 MB per upload).
   - Turn on Pages in repo Settings > Pages (source: main branch, or a GitHub Actions workflow).
   - Optional custom domain: add it in Pages settings and point the domain's DNS at GitHub.
3. **Their existing site builder** (Squarespace, Shopify, Wix, WordPress): Claude writes the copy and HTML embed blocks, then places them through the browser if asked.

Site structure: Home (first person intro, track buttons), one page per track listing its pieces, one page per case study, About, Contact (email and LinkedIn, no forms needed), Resume.

Design: clean, fast, mobile friendly, 16px side margins on phones, the person's own style. One accent color family used everywhere. Embed videos instead of uploading huge files.

**Build from one template.** Generate every page from a single script or template that owns the header, footer, nav and shared CSS. Never hand edit one page's header. When someone (or another session) adds a link or page to the live site, pull the latest site first and fold that change into the template before the next upload, or the upload will erase it.

**Host everything on the site.** Never send visitors to Google Drive, Dropbox or a PDF viewer for "more examples". Bring those pieces onto real pages.

## Baseline quality bar: showing the work

These are the defaults for every portfolio site. Most come from real client revision rounds.

**Fit the format to the piece**
- Show every piece at its **real aspect ratio**. Never crop ads, social posts, brand guides or posters to fit a grid.
- Long web pages and funnels: a **browser frame you scroll yourself**, with a visible scrollbar, a "scroll to explore" hint, and padding inside the frame so the page never touches the edges.
- Mobile screens: a **realistic phone frame**, with tabs when there are several screens. Before screenshotting, force lazy images to load (scroll the whole page or set images to eager), or sections like Instagram feeds come out blank.
- Multi-page documents (catalogs, workbooks, proposals, line sheets, tech packs, zines): one continuous scroll, a flipbook, or a popup that scrolls the **full document**. Use sharp source files so pages are never grainy.
- Ads: inside the platform's real UI (an Instagram post frame, a phone for stories). Keep text to about 20% of the image, following Meta's guidance. Put the long message in the caption.
- Video: short, muted, looping clips in a tidy grid (2x2 or rows of phones). Crop out borders and dead space. Label each by industry or purpose.
- Before and after: a drag slider or a side-by-side pair. The before must be the **true original of the same item**. If no true before exists, drop the pair.
- Product design: pair tech packs or mockups with photos of the finished product when they exist.
- Physical mockups (window clings, signage, print): align them to one consistent height and edge.

**Interaction**
- Click to enlarge only where it helps (dense documents, detailed images). Small logos, brand cards and already-full-size images stay unclickable.
- Long pages get a jump menu at the top.
- Every service or package card links to the case study that proves it ("See the [project] case study" with an arrow), at the bottom of the card.
- Portfolio hub thumbnails: the single strongest, most on-brand image for each category.
- Resume page: a real HTML resume with a fixed top bar (name, location, email, LinkedIn) and a Download PDF button. Not a PDF preview.
- Stat tiles must fit on one line at every screen width. Shorten the label ("+12% AOV") rather than shrink it to nothing.
- External links open in a new tab.

**Typography**
- No widows or orphans: join the last two words of headings, captions and short paragraphs with a non-breaking space.

## Baseline quality bar: copy and facts

- Use only locked numbers from the proof bank. Never round up, merge, or invent. If a metric went down, leave it out instead of spinning it.
- Keep identities separate: a personal account is never credited to a brand, and a brand's numbers are never credited to a person.
- Concept and spec work is always labeled as a concept, never as a paid client.
- Describe the working relationship accurately (contractor, agency, own business name, employee).
- Say what something **is**, not what it isn't.
- Apply the person's own style rules everywhere (punctuation they avoid, words they dislike, voice). Check every page with a search before publishing.
- Counts in copy must match what's on the page ("three ways to work" means three cards are shown).
- Run a full copy and fact pass across every page at the end of each revision round. Make the resume and the site say the same thing.

## Baseline quality bar: privacy and permission

- Get permission before showing client names and visuals. Licensed stock in client work is fine to show.
- Blur only what's private, not whole sections: customer names in testimonials, private contact details, order numbers.
- Performance dashboards: keep the conversion numbers visible (that's the proof). Blur client and product names only if the person asks.
- Teammates stay unnamed unless they agree to be named.
- A community or customer showcase shows the community, not the portfolio owner. Credit people by their public handles when they shared publicly.
- Flag anything uncertain (a face that might be the owner, an old handle, a mislabeled file) as an open task instead of guessing.

## Baseline quality bar: AI photo edits

- Keep the real product exactly as it is. Change the scene, light and styling only.
- Match the brand's look and subculture. Research the aesthetic first and avoid blank studio backdrops for lifestyle brands.
- Keep color consistent with the original (hair, makeup, garments).
- Food and products: restage plain or overhead shots into on-brand settings, and keep strong close-ups as they are.
- Show before and after contact sheets so the person can approve the edits.

## Revision rounds

1. Turn the person's notes into a numbered checklist. Add notes that arrive mid-round to the same list.
2. Fix assets first, then rebuild every page from the template.
3. QA before upload: no sideways scroll at 390px and 1280px wide, the style rule search, the widow check, and a visual check of every changed section.
4. Upload, wait for the deploy, then confirm every file the pages reference loads on the live site, and the live pages match the build.
5. Report in plain words: what changed, then an **Open Tasks** list of only the decisions the person must make. Attach before and after sheets. Log the round in the Career Profile.

## Spec projects

Use a spec project when a track has no proof, or when one specific job is worth winning with custom work.

1. **Brief:** start from a real job post or client type. Pull what they want to see (aesthetic, deliverables, platforms).
2. **Concept:** brand name, positioning, audience, voice, palette, type pairing, product or service list. Mark it clearly as a concept (example footer: "Concept brand by [Name]. Not for sale.").
3. **Make the visuals fast:**
   - Brand board, social posts, email designs, landing pages and web mockups as **HTML artifacts** (Claude builds them directly).
   - Product and lifestyle images with an image generator the person has (ChatGPT images, Gemini, Firefly, Midjourney, ComfyUI). Claude writes the prompts and the shot list.
   - Decks with the Slides type or Google Slides.
4. **Real platform proof (optional):** a free Shopify Partner development store for an ecommerce build, a free email tool account for an email campaign, or a static GitHub Pages snapshot so there is a no password demo link.
5. **Case study:** write it up with the template above, including process shots.
6. **Log it:** add the project and links to the Asset Library in the Career Profile.

Keep it honest: never present a spec project as a paid client.

## Export for applications

- Many forms want a PDF under 10 MB. Export each track portfolio and key case studies as PDF (Playwright `page.pdf` in a cloud session, or browser Save as PDF).
- Compress big images before export.
- Name files `First Last Portfolio [Track].pdf` and `[Project] Case Study.pdf`.
- Update the Asset Library table in the Career Profile with links and dates.

## When done

Tell the person in plain words what was built, which track each piece now covers, which tracks still lack proof, and attach or link the actual files and pages.
