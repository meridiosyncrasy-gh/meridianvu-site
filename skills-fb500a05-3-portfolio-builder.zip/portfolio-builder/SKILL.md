---
name: portfolio-builder
description: "Step 3 of the job search skill set. Turns a person's real work into proof employers can see: case studies, track-specific portfolio versions, and a portfolio website hosted free on GitHub Pages or as Claude artifacts. Also plans and builds spec projects (made-up brands or concepts built to fill a portfolio gap or win one specific job) using HTML mockups, AI images and optional Shopify dev stores, instead of slow manual tools. Exports PDFs for job forms. Use for \"build my portfolio\", \"write a case study\", \"make a portfolio site\", \"I have no proof for this kind of role\", \"make a spec project for this job\", \"update my portfolio for [track]\", or \"export my portfolio to PDF\". Reads the Career Profile. Works for any person and field."
---

# Portfolio Builder

Part of a six skill job search set (career-goal-mapping, resume-builder, portfolio-builder, job-screening, application-writer, interview-prep-follow-up).

## Before you start

1. Read the **Career Profile** (`career-profile.md` in the Claude project). If missing, run **career-goal-mapping** first.
2. Inventory existing work: old portfolios (PDF, Slides, Canva, Behance), case studies, live links, Drive folders of assets, videos. Read or look at all of it.
3. Map work to tracks: for each track in the profile, list which pieces prove it and which tracks have **no proof yet**. Show this map to the person. A track with no proof needs a case study from real work or a spec project.

## The portfolio system

- **Case studies:** deep proof for one project. 1 to 6 pages. The strongest thing to link in an application.
- **Mini case studies:** one slice of a big case study (example: just the AI image pipeline from a bigger store build). Fast to make, very targeted.
- **Track portfolios:** a curated set of pieces per track. Make variants by reordering and trimming sections, not by rewriting everything.
- **Portfolio home:** one website that holds it all, with a page or anchor per track.
- **Spec projects:** made-up but fully executed projects that prove a skill there is no paid work for yet.

## Case study template

Use this 5 part shape. It reads like a story, not a report:

1. **The Big Idea:** one or two sentences on what was built and why it matters.
2. **The Real Problem:** what was broken or missing before, in plain words.
3. **What I Built:** the system, steps, tools, and decisions. Include visuals: before and after, screenshots, process diagrams.
4. **The Result:** numbers from the proof bank (time saved, output volume, growth, sales). Only proof bank numbers.
5. **What This Proves for You:** one short paragraph tying it to what the target employer needs.
6. **Proof links:** live site, SOP docs, video walkthrough (Loom or similar), asset folders.

Header block: title, subtitle with the client or brand, byline with name and the track title, then "Platform" and "Goal" lines. End with a short first person contact block.

## Portfolio rules that work

- Bio and all copy in **first person**. Never third person.
- Do not open with "thank you for considering me". Open with who you are and what you do. Put the call to action ("open to new roles, let's talk") on the **last page only**.
- One benefit sentence per piece, written to the reader ("decks that help your team win the room").
- Label visuals so a skimmer gets it in 3 seconds.
- Specialize per track. Cutting good but off-topic work makes the portfolio stronger.
- For pure design roles, swap marketing jargon (funnel, conversion, growth) for design words (UI, visual system, asset creation). For marketing roles, do the reverse and lead with numbers.
- Be honest about AI and tools. Say what was AI assisted. Many employers want to see it.
- Check every link works before exporting.

## Building the portfolio home

Pick what fits the person, in this order:

1. **Claude artifacts (fastest):** each case study as an HTML artifact page, plus a hub page linking them. Private until they share. Good for quick links in applications.
2. **GitHub Pages (free, real web address):** a static site in a repo, auto published. Steps:
   - Person creates a free GitHub account (sign in with Google if offered).
   - Create a repo named `[username].github.io` for a main site, or any name for a project site.
   - Claude writes the site files (index.html, one page per case study, an assets folder). Push with the `gh` command line tool if signed in, or upload through the GitHub web page in the browser.
   - Turn on Pages in repo Settings > Pages (source: main branch, or a GitHub Actions workflow).
   - Optional custom domain: add it in Pages settings and point the domain's DNS at GitHub.
3. **Their existing site builder** (Squarespace, Shopify, Wix, WordPress): Claude writes the copy and HTML embed blocks, then places them through the browser if asked.

Site structure: Home (first person intro, track buttons), one page per track listing its pieces, one page per case study, About, Contact (email and LinkedIn, no forms needed), Resume (PDF download).

Design: clean, fast, mobile friendly, 16px side margins on phones, the person's own style. Embed videos instead of uploading huge files.

## Spec projects

Use a spec project when a track has no proof, or when one specific job is worth winning with custom work.

1. **Brief:** start from a real job post or client type. Pull what they want to see (aesthetic, deliverables, platforms).
2. **Concept:** brand name, positioning, audience, voice, palette, type pairing, product or service list. Mark it clearly as a concept (example footer: "Concept brand by [Name]. Not for sale.").
3. **Make the visuals fast:**
   - Brand board, social posts, email designs, landing pages and web mockups as **HTML artifacts** (Claude builds them directly).
   - Product and lifestyle images with an image generator the person has (ChatGPT images, Gemini, Firefly, Midjourney, ComfyUI). Claude writes the prompts and the shot list.
   - Decks with the Slides type or Google Slides.
4. **Real platform proof (optional):** a free Shopify Partner development store for an ecommerce build, a free email tool account for an email campaign, or a static GitHub Pages snapshot so there is a no password demo link.
5. **Case study:** write it up with the template above, including process shots.
6. **Log it:** add the project and links to the Asset Library in the Career Profile.

Keep it honest: never present a spec project as a paid client.

## Export for applications

- Many forms want a PDF under 10 MB. Export each track portfolio and key case studies as PDF (Playwright `page.pdf` in a cloud session, or browser Save as PDF).
- Compress big images before export.
- Name files `First Last Portfolio [Track].pdf` and `[Project] Case Study.pdf`.
- Update the Asset Library table in the Career Profile with links and dates.

## When done

Tell the person in plain words what was built, which track each piece now covers, which tracks still lack proof, and attach or link the actual files and pages.
