---
name: "portfolio-builder"
description: "Step 3 of 7 in the job search skill set. Turns a person's real work into proof employers and clients can see: case studies, track portfolios, and a portfolio website hosted free on GitHub Pages or as Claude artifacts. Works in two stages: Stage 1 drafts and builds the full site to a built-in quality bar (copy, navigation, speed, search, analytics, share previews). Stage 2 has ChatGPT review it blind, area by area, then Claude judges each suggestion and ships the keepers. Also runs consistency audits after new work is added, plans spec projects, runs revision rounds and exports PDFs. Use for \"build my portfolio\", \"write a case study\", \"make a portfolio site\", \"fix up my portfolio site\", \"have ChatGPT review my site\", \"make my site consistent\", \"make a spec project for this job\", \"update my portfolio for [track]\", or \"export my portfolio to PDF\". Reads the Career Profile. Works for any person and field."
---

# Portfolio Builder

Step 3 of 7 in the job search skill set: career-goal-mapping, resume-builder, portfolio-builder, job-board-profiles, job-screening, application-writer, interview-prep-follow-up.

The goal is a polished, professional site on the first pass. Work in two stages:

- **Stage 1: Draft and build.** Write and build everything to the quality bar in this file, then QA and publish.
- **Stage 2: Outside review and execute.** ChatGPT reviews the live site blind, one area at a time. Claude decides which suggestions are real improvements, applies them, QAs and republishes in the same session.

Do not stop between stages to ask permission. Run Stage 2 right after Stage 1 unless the person said to skip it.

## Core rule: no long dashes (applies to every person)

This rule is part of the skill and does not change per person. Every word this skill produces follows it: site copy, headings, buttons, image alt text, meta titles and descriptions, share preview text, JSON-LD, llms.txt, case studies, PDFs, resume text on the site, and the reports Claude sends the person.

- Never use the em dash (—) or the en dash (–). The plain hyphen (-) is fine for compound words like "short-form" or "on-brand".
- Rewrite instead of swapping one dash for another:
  - Two related ideas become two separate sentences.
  - A label and its detail use a colon ("Speed: pages load in under 2 seconds").
  - A list of side-by-side items, or a title and a name, uses a vertical bar ("AI Systems | Shopify Growth").
  - Number ranges use "to" ("2018 to 2022", "$1,500 to $3,000").
- Treat suggestions from ChatGPT or any other tool the same way. Rewrite any long dash in them before applying.
- Before every publish, search all files for "—", "–", "&mdash;", "&ndash;", "&#8212;" and "&#8211;". The count must be zero.

The person's other style preferences (words to avoid, tone, spelling) come from their Career Profile and change per person.

## Before you start

1. Read the **Career Profile** (`career-profile.md` in the Claude project). If missing, run **career-goal-mapping** first.
2. Inventory existing work: old portfolios (PDF, Slides, Canva, Behance), case studies, live links, Drive folders of assets, videos. Read or look at all of it.
3. Map work to tracks: for each track in the profile, list which pieces prove it and which tracks have **no proof yet**. Show this map to the person. A track with no proof needs a case study from real work or a spec project.
4. Collect the **locked facts** before writing a word: numbers from the proof bank, which accounts are personal vs brand, which projects are paid clients vs concepts, how the person was engaged (employee, contractor, own business name), who may be named, and each client's preferred short name. Ask once and save the answers to the Career Profile.
5. **Decide the site's one job** and write it in one sentence. Examples: "win freelance clients for AI systems work" or "get hired as a senior product designer". Everything else (page order, headlines, calls to action) serves that sentence. Name the main action a visitor should take (email me, book a call, download resume).

## The portfolio system

- **Case studies:** deep proof for one project. 1 to 6 pages. The strongest thing to link in an application.
- **Mini case studies:** one slice of a big case study (example: just the AI image pipeline from a bigger store build). Fast to make, very targeted.
- **Track portfolios:** a curated set of pieces per track. Make variants by reordering and trimming sections, not by rewriting everything.
- **Portfolio home:** one website that holds it all, with a page or anchor per track.
- **Spec projects:** made-up but fully executed projects that prove a skill there is no paid work for yet.

## Case study template

Use this shape. It reads like a story, not a report:

1. **The Big Idea:** one or two sentences on what was built and why it matters.
2. **The Real Problem:** what was broken or missing before, in plain words.
3. **Before and after table:** right after The Big Idea or The Real Problem, so a skimmer sees the result early.
4. **What I Built:** the system, steps, tools, and decisions. Include visuals: before and after, screenshots, process diagrams.
5. **The Result:** numbers from the proof bank only.
6. **What This Proves for You:** one short paragraph tying it to what the reader needs.
7. **Proof links:** live site, SOP docs, video walkthrough, asset folders.
8. **Next steps block:** contact button, a link to the matching service or package, and two related case studies.

Header block: an "All case studies" back link, title, subtitle with the client or brand, then "Platform" and "Goal" lines.

## Portfolio rules that work

- Bio and all copy in **first person**. Never third person.
- Do not open with "thank you for considering me". Open with who you are and what you do. In PDF portfolios, put the call to action on the **last page only**. On a website, end every page with a contact band.
- Label visuals so a skimmer gets it in 3 seconds.
- Specialize per track. Cutting good but off-topic work makes the portfolio stronger.
- For pure design roles, swap marketing jargon (funnel, conversion, growth) for design words (UI, visual system, asset creation). For marketing roles, do the reverse and lead with numbers.
- Be honest about AI and tools. Say what was AI assisted. Many employers want to see it.
- Check every link works before exporting.

---

# STAGE 1: DRAFT AND BUILD

## Building the portfolio home

Pick what fits the person, in this order:

1. **Claude artifacts (fastest):** each case study as an HTML artifact page, plus a hub page linking them. Private until they share.
2. **GitHub Pages (free, real web address):** a static site in a repo, auto published.
   - Person creates a free GitHub account (sign in with Google if offered).
   - Create a repo named `[username].github.io` for a main site, or any name for a project site.
   - Claude writes the site files. Push with the `gh` tool if signed in, or upload through the GitHub web page in the browser. Web uploads take about 10 MB per upload, and batches of 4 to 5 files fail less often. Wait for the file list to show before clicking Commit.
   - For many files or subfolders (an image library), add a small GitHub Actions workflow that unzips any uploaded `bundle-*.zip` into place, deletes files listed in an optional `_delete.txt`, commits, then calls the Pages build API (`POST repos/{repo}/pages/builds`), because commits made by the Actions bot do not trigger a Pages rebuild on their own. Ask before adding a workflow.
   - Turn on Pages in Settings > Pages. Optional custom domain: add it there and point DNS at GitHub.
3. **Their existing site builder** (Squarespace, Shopify, Wix, WordPress): Claude writes the copy and HTML embed blocks, then places them through the browser if asked.

Site structure: Home, Services (if freelance), Case studies, Portfolio hub, one page per project, Resume, Contact (email and LinkedIn, no form needed).

Design: clean, fast, mobile friendly, 16px side margins on phones, the person's own style. One accent color family used everywhere. Embed videos instead of uploading huge files.

**Build from one template.** One script or template owns the header, footer, nav and shared CSS. Never hand edit one page's header. Before any upload, pull the latest live site and fold in anything changed elsewhere, or the upload erases it.

**When another session edits the same site.** Write copy changes as a re-runnable list of exact find and replace pairs (a small script), not hand edits. Pull the latest site right before uploading, reapply the list, and upload only the files that changed. Tell the other session to pull before its next upload. If the person says another session is uploading, stop uploading until they say it is done. Keep making assets and page edits in the meantime, then pull and reapply right before publishing.

**No push access.** On GitHub's web upload page in a signed-in browser, page JavaScript can fetch the current files from raw.githubusercontent.com, apply the find and replace pairs, and attach the results to the upload form's file input with a DataTransfer. Compare each result's length or hash with the local build before committing. Keep anything carried into the page in sessionStorage, because navigating clears page variables.

**Host everything on the site.** Never send visitors to Drive, Dropbox or a PDF viewer for "more examples".

## Quality bar: navigation and layout

- **Header:** logo or monogram is the Home link, 3 to 4 main links, a "More" dropdown for secondary pages (resume, free resources), and one main call to action button on the right. Offer a simple monogram icon instead of a headshot in the logo slot. Many people prefer it.
- **Phones:** a real "Menu" button that opens a panel. Keep the call to action button visible. Never a sideways scrolling strip of links.
- **Footer:** grouped links (Explore, More, Contact), plus a "Copy email" button next to the email link.
- **Contact band** at the bottom of every page, with copy matched to that page.
- **Home order:** hero with the one main promise, proof stats (each links to its case study), what I can help with (strongest offer first), case studies, process, about, a short gallery, contact.
- **Card rows:** cards in one row share a bottom edge. Buttons line up on one level across cards, and the links under them sit in a fixed-height group, so a card with one link lines up with a card that has two.
- **Home page featured rows:** the strongest and most varied pieces, never repeating work already featured in another section of the same page. Recheck the row whenever new work is added.
- **Services:** the person's lead offer first. Every package card has an id, a price if they publish prices, a link to the case study that proves it, and an "Ask about this package" email button with the package name in the subject line. A short "find your starting point" chooser at the top helps visitors pick.
- **Long pages, including the portfolio hub:** a jump bar of section buttons that sticks under the header while scrolling on desktop and highlights the current section. On phones it sits at the top and wraps, not sticky. Give sections a scroll margin so headings are not hidden under the bars.
- **Portfolio hub:** groups by track with jump buttons. Tags (Client work, Concept, Own brand) only where the facts support them.
- **Project pages:** back links at the top and bottom.
- **Resume page:** a real HTML resume, not a PDF preview. The name, location, email, LinkedIn and Download PDF button sit at the top of the page and scroll away normally (not sticky). The resume itself sits in its own box sized to the screen, and only the box scrolls. No divider line between the name area and the box, so it reads as one seamless page.
- **Accessibility:** a skip to content link, visible focus rings, tap targets at least 44px, motion stops for people who turn on reduced motion, and text color that passes contrast checks.

## Quality bar: showing the work

**Fit the format to the piece**
- Show every piece at its **real aspect ratio**. Never crop ads, social posts, brand guides or posters to fit a grid. Group pieces by format instead: square ads with square ads, pins with pins, so each grid reads as one clean set.
- **Client work looks like the client.** Each client piece follows that client's own brand guide (colors, fonts, motifs). The portfolio owner's own brand details (signature icons, flourishes, accent colors) never appear in client work. When several clients are shown together, give each brand visible space, such as one piece per brand in a hero row, so the range reads at a glance.
- **Thumbnails and feed mockups are designed pieces.** Use finished graphics in one cohesive look. Never mix in raw product photos or video stills that break the set. When real client assets cannot be shown together, a clearly fictional brand built in the same style works.
- **Before and afters:** show 4 to 6 pairs, at one aspect ratio, so the set does not feel thin.
- Long web pages and funnels: a **browser frame you scroll yourself**, with a visible scrollbar and padding inside the frame.
- Mobile screens: a **realistic phone frame**, with tabs when there are several screens. Force lazy images to load before screenshotting.
- Multi-page documents: one continuous scroll, a flipbook, or a popup that scrolls the **full document**. Use sharp source files.
- Ads: inside the platform's real UI. Keep text to about 20% of the image. Put the long message in the caption.
- Video: short, muted, looping clips in a tidy grid. Crop out borders. Label each by industry or purpose.
- Before and after: a drag slider or a side-by-side pair. The before must be the **true original of the same item**, or drop the pair.
- Product design: pair tech packs or mockups with photos of the finished product.
- Physical mockups: align them to one consistent height and edge.

**Interaction**
- Click to enlarge only where it helps (dense documents, detailed images). Small logos, brand cards and already-full-size images stay unclickable.
- Portfolio hub thumbnails: the single strongest, most on-brand image for each category. Check faces are not cropped at the top.
- Stat tiles fit on one line at every width. Shorten the label rather than shrink it.
- External links open in a new tab.
- Do not add "how to use this" instructions ("Scroll inside the frame", "Tap a tab", "Click to enlarge"). Good design makes them unneeded.

**Typography**
- No widows: join the last two words of headings, captions and short paragraphs with a non-breaking space.

## Quality bar: copy and facts

- **Lead with the site's one job.** The hero headline states the main promise to the reader in plain words.
- **Headline pairs:** the H1 makes the promise. The subheadline adds scope or proof and never repeats the H1 or starts the same way ("How I..." followed by "How I..."). The small eyebrow label and the heading under it never echo each other.
- **Cut filler.** Remove small disclaimers and notes that do not help a visitor decide to hire the person: "names left out", "shared with permission", "counts come from logs", viewing instructions. Keep lines that build trust, such as how a number was measured or that a human reviews the output.
- **Client names:** use the client's recognizable short name, never a bare acronym the reader will not know. Use the full name on first mention per page.
- Use only locked numbers from the proof bank. Never round up, merge, or invent. If a metric went down, leave it out.
- Keep identities separate: a personal account is never credited to a brand, and the reverse.
- Concept and spec work is always labeled as a concept.
- Describe the working relationship accurately (contractor, agency, own business, employee).
- No badges or claims without proof ("Most popular" needs real sales history; "Recommended" is honest).
- Never promise content that does not exist yet ("videos coming soon").
- Say what something **is**, not what it isn't.
- One benefit sentence per piece, written to the reader. First person everywhere.
- Text baked inside real client images stays as it is.
- Follow the core no long dashes rule everywhere. Then apply the person's own style rules (words they dislike, tone, voice). Search every page before publishing.
- Counts in copy must match what's on the page.
- Make the resume and the site say the same thing.
- **Lead with the result, not the inputs.** "Saves about 190 hours a week" beats "150 hours plus up to 60 of mine": readers add up the parts and stumble when the sum doesn't match the claim.
- **Name a metric for what it measures.** Clicks are clicks, not shoppers or customers. Every growth number carries its comparison period ("since Sep 1 vs the same dates last year").
- **Designs are designs.** A mockup or concept storefront is "designed", never "designed and built".
- **One spelling of every name**, everywhere: body copy, cards, page titles, share tags, JSON-LD and image alt text.

## Quality bar: privacy and permission

- Get permission before showing client names and visuals. Licensed stock in client work is fine to show.
- Blur only what's private: customer names, private contact details, order numbers.
- Performance dashboards: keep the numbers visible. Blur names only if the person asks.
- Teammates stay unnamed unless they agree.
- A community or customer showcase shows the community, not the portfolio owner. Credit people by their public handles when they shared publicly.
- Flag anything uncertain as an open task instead of guessing.

## Quality bar: AI photo edits

- Keep the real product exactly as it is. Change the scene, light and styling only.
- Match the brand's look and subculture. Avoid blank studio backdrops for lifestyle brands.
- Keep color consistent with the original (hair, makeup, garments).
- Food and products: restage plain or overhead shots into on-brand settings, and keep strong close-ups as they are.
- Show before and after contact sheets so the person can approve.

## Quality bar: speed, search, AI answers and tracking

Do all of these on the first build. They are invisible to visitors but decide whether the site is found and fast.

- **Speed:** convert images to WebP (about 1800px wide max, quality around 78), lazy load images below the first screen, decode async. Aim for under 3 MB on most pages and under 7 MB on the heaviest. Delete unused originals once the new files are live.
- **Search basics:** a unique title (about 60 characters) and meta description (about 155) per page, a canonical tag, `sitemap.xml`, `robots.txt`, and descriptive alt text on every image. Let Google index every real work page. Hide only truly private pages (noindex plus a robots.txt disallow).
- **Structured data (JSON-LD):** Person on every page, ProfessionalService with an offer catalog and prices on Services (if freelance), Article on case studies, WebSite on home.
- **AI answers:** an `/llms.txt` file with a plain summary of who the person is, services and prices, and links to each case study.
- **Google Search Console:** in the browser, add a URL prefix property, verify with the HTML meta tag on the home page (that tag must stay forever), then submit the sitemap. Click through Google sign-in yourself.
- **Google Analytics 4:** create a property and web stream, add the tag to every page, and send events for contact actions (email link clicks as `generate_lead` with the subject line, package questions, copy email, LinkedIn clicks). Link GA to Search Console. After the first lead event arrives (usually within a day), mark it as a key event, so schedule a follow-up to do that.
- **Share previews:** one 1200x630 image per page, built from a single HTML template (person's name and icon, a short kicker label, a headline, one proof line, and a photo on the right or a text-only variant). Add Open Graph and Twitter tags to every page. Check no face is cropped at the top. When replacing an image, add `?v=2` to its URL so platforms refetch it. LinkedIn caches previews, so suggest its Post Inspector once.
- **Favicon set:** favicon.ico, an SVG, a 32px PNG and a 180px Apple touch icon, all from the same current mark. Let the artwork fill the square at tab size (no outer ring or padding). When the icon changes, add `?v=2` to every icon link on every page, because Safari keeps old favicons for a long time.
- **Mobile menu:** every link in the open menu uses the same style, including secondary links like Resume or Home.
- **Monthly health check:** offer a monthly scheduled task that checks every sitemap page for broken links and images, the share images, the analytics and verification tags, and page weight, then sends a plain summary. It only reports and never edits.

## Stage 1 QA and publish

1. No sideways scroll at 390px and 1280px wide. In two-column layouts, check the longest heading still fits its column with a clear gap before the next column. Screenshot key pages at both widths and look at them.
2. Long dash search (must be zero), the person's style rule search, widow check, and a copy and fact pass on every page.
3. Upload, wait for the deploy, then confirm every file the pages reference loads on the live site and the live pages match the build.

---

# STAGE 2: OUTSIDE REVIEW AND EXECUTE

A second model reviewing blind catches what the builder stops seeing. ChatGPT proposes, Claude judges, Claude executes. The person does not approve each line.

## Setup

- Open https://chatgpt.com in the browser. Start a **Temporary chat** and turn off personalization or memory if offered, so it reviews with no context about the person. If a login appears, click through it (sign in with Google if offered).
- If ChatGPT is not available, use a fresh Claude subagent given only the site URL and the round's prompt.
- Give it the live URL plus page URLs. If it cannot open a page, retry once, then paste the page text or upload screenshots instead.
- Never paste private info, passwords or unpublished client details into the chat.
- Tell ChatGPT in each round that the site never uses em dashes or en dashes, so its suggested copy should not either.

## The review rounds

Run these in order. Each round: ChatGPT proposes, Claude filters, Claude applies, QA, publish.

1. **Purpose and copy.** Ask ChatGPT, with no context, what it thinks the site's purpose and audience are and to propose an outline for improving the copy toward that purpose. Compare to the one job sentence from Before you start. If they match, ask for copy edits as exact find and replace pairs per page, including text inside thumbnails. If they do not match, the site is not communicating its job: fix the hero and page order first, then rerun.
2. **Filler and headline pairs.** Ask it to list lines that do not help a visitor decide (disclaimers, instructions, repeats) and every headline, subheadline and eyebrow pair that echoes or starts the same way, with fixes.
3. **UI, UX and navigation.** Send desktop and 390px phone screenshots of every page. Give it the build limits (static site, email instead of a form, keep the look and fonts). Ask for navigation, layout, mobile and accessibility fixes, ranked by impact.
4. **Share previews.** Ask it to design the preview card system and write each page's preview title, description and on-image text. Claude builds the images.

## How Claude judges each suggestion

Keep a suggestion only if it serves the site's one job and passes the quality bar. Reject when it:
- adds a number, claim or client detail not in the proof bank
- makes a card or headline longer without making it clearer
- swaps a specific label for a vague one, or replaces a stronger original
- breaks the core no long dashes rule (rewrite it, then judge it), the person's style rules or the build limits
- is a sideways move (different words, same value)

## Execute and report

- Apply the keepers in one pass from the template, run Stage 1 QA, publish and verify live.
- Save a short log to the project: each round's main changes and what was rejected and why.
- Report to the person in plain words: what changed on the site, the few notable suggestions that were rejected, and an **Open Tasks** list of only the decisions they must make.

---

## Consistency audit (after adding new work)

New pages and cards leave older pages behind. Run this whenever new work is added, and before a job search push.

1. **Crawl everything:** every sitemap page, llms.txt, the resume page and the resume PDF. Extract the text.
2. **Locked fact sheet:** list every number, date, name and title with its source. Search every file for each one and fix any page that disagrees. llms.txt, meta descriptions, share text and JSON-LD drift first because no visitor sees them.
3. **Cross-links:** every service package links to its strongest proof. New work appears on the portfolio hub under the track it proves. Compilation pages' counts ("feeds for six brands") match their sections. Search link text, card text, page titles and share text for hard-coded counts ("see all three") and prefer wording that doesn't go stale ("see every feed"). When the scope of a section changes (launch work becomes launch and refresh work), update the page title, H1, chips, card copy and share image together. The home page features the newest strong work.
4. **Links and images:** every reference returns 200.
5. **Outside review:** run Stage 2 rounds 1 and 2 framed as a consistency audit (stats, names, angles, missing links, instruction lines), with exact find and replace pairs. ChatGPT often cannot open .txt files or some pages, so paste those in.
6. Apply, QA, publish, and confirm the live files match the build byte for byte.

## Revision rounds (any time later)

1. Turn the person's notes into a numbered checklist. Add notes that arrive mid-round to the same list.
2. Fix assets first, then rebuild every page from the template.
3. Run Stage 1 QA, upload, verify live.
4. If the person asks for an outside opinion on a specific area, run just that Stage 2 round.
5. Report in plain words with an **Open Tasks** list. Attach before and after sheets. Log the round in the Career Profile.

## Spec projects

Use a spec project when a track has no proof, or when one specific job is worth winning with custom work.

1. **Brief:** start from a real job post or client type. Pull what they want to see (aesthetic, deliverables, platforms).
2. **Concept:** brand name, positioning, audience, voice, palette, type pairing, product or service list. Mark it clearly as a concept (example footer: "Concept brand by [Name]. Not for sale.").
3. **Make the visuals fast:**
   - Brand board, social posts, email designs, landing pages and web mockups as **HTML artifacts** (Claude builds them directly).
   - Product and lifestyle images with an image generator the person has (ChatGPT images, Gemini, Firefly, Midjourney, ComfyUI). Claude writes the prompts and the shot list.
   - Decks with the Slides type or Google Slides.
4. **Real platform proof (optional):** a free Shopify Partner development store for an ecommerce build, a free email tool account for an email campaign, or a static GitHub Pages snapshot so there is a no password demo link.
5. **Case study:** write it up with the template above, including process shots.
6. **Log it:** add the project and links to the Asset Library in the Career Profile.

Keep it honest: never present a spec project as a paid client.

## Export for applications

- Many forms want a PDF under 10 MB. Export each track portfolio and key case studies as PDF (Playwright `page.pdf` in a cloud session, or browser Save as PDF). Compress big images first.
- Name files `First Last Portfolio [Track].pdf` and `[Project] Case Study.pdf`.
- Update the Asset Library table in the Career Profile with links and dates.

## When done

Tell the person in plain words what was built, which track each piece now covers, which tracks still lack proof, and what Stage 2 changed. Attach or link the actual files and pages.