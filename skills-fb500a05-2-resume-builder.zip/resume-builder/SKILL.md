---
name: "resume-builder"
description: "Step 2 of 7 in the job search skill set. Builds, fixes and tailors resumes from the person's Career Profile proof bank. Makes one master resume plus one version per career track, designed as an HTML artifact the person can see and tweak, then exported to a clean PDF. Runs an ATS check (plain headings, real bullets, keyword skills, no emoji), a truth check (numbers match the proof bank, no merged stats, no banned phrases), and can tailor a version to one job post. Hands off to job-board-profiles to update LinkedIn, Indeed, ZipRecruiter and Upwork. Use for \"update my resume\", \"make a resume for [role type]\", \"tailor my resume to this job\", \"is my resume ATS friendly\", \"export my resume to PDF\", or \"make my resume versions match\". Works for any person and field."
---

# Resume Builder

Step 2 of 7 in the job search skill set: career-goal-mapping, resume-builder, portfolio-builder, job-board-profiles, job-screening, application-writer, interview-prep-follow-up.

## Core rule: no long dashes (applies to every person)

This rule is part of the job search skill set and does not change per person. Everything this skill writes follows it: every resume version (HTML and PDF), tailored copies, file names, the LinkedIn headline, About section and bullets, and the messages Claude sends the person.

- Never use the em dash (—) or the en dash (–). The plain hyphen (-) is fine inside words like "full-time" or "30-60-90".
- Rewrite instead of swapping one dash for another:
  - Two related ideas become two separate sentences.
  - A label and its detail use a colon ("Pay: $85K to $95K").
  - Side-by-side items, or a title and a name, use a vertical bar ("Designer | Acme Co").
  - Ranges use "to" ("Jan 2024 to Mar 2026", "$78K to $96K").
- Text pulled from job posts, old resumes, templates, ChatGPT or any other tool gets rewritten the same way before it goes into anything this skill makes. Direct quotes from a job post on a screening card are the only exception.
- Before showing, saving or sending anything, search it for "—", "–", "&mdash;", "&ndash;", "&#8212;" and "&#8211;". The count must be zero.

The person's other style preferences (words to avoid, tone, greetings) come from the Voice Rules in their Career Profile and change per person.

## Before you start

1. Read the person's **Career Profile** (`career-profile.md` in their Claude project, or the doc they point to). If there is none, run **career-goal-mapping** first. A resume without a proof bank turns into guesswork.
2. Collect their current resume files (attachments, Google Drive, Indeed connector `get_resume`). Read every version.

## The resume system

- **Master resume:** every role, every proof bank win, every skill. Never sent out. It is the parts bin.
- **Track versions:** one per track in the Career Profile (for example "Senior Designer" vs "Graphic Designer" vs "Marketing"). Same facts, different order, title framing and depth.
- **Tailored copy:** a track version adjusted for one specific job. Made only when the job is worth it (job-screening says Apply).

What changes between versions: headline, summary, which side roles get their own entry, the order of roles and bullets, the job title framing for the same role (only if honest), skills order, jargon level, and which portfolio links show. What never changes: dates, numbers, employers, degrees.

- **Selective, not complete.** Each track version keeps only the proof a recruiter for that role checks for, in that role's job post words. Cut wins that prove a different track even when they are impressive (follower counts on an operations resume, cost savings on a graphic design resume). Leaving a whole side role off one version is fine. The master resume holds everything else.
- **One shape per engagement.** A given contract or client has the same structure in every version (its own entry everywhere, or a line under one umbrella entry everywhere) and the same dates.
- **Website version.** If the person has a portfolio site, its resume page is its own version aimed at the site's one job (often clients, not recruiters), and the site's Download PDF button gives that version.

## Step 1: Audit what exists

Check each current version and list problems in plain words, grouped:

**Truth check**
- Any em dash or en dash (core rule). Rewrite each one.
- Numbers that disagree between versions or with the proof bank (example: a catalog size listed as three different numbers). Use the proof bank number.
- Stats that merge separate wins into one bigger claim. Split them.
- Growth numbers with no comparison period ("sales up 70%"). Add it ("since Sep 1 vs the same dates last year").
- Metrics named for more than they measure (clicks called shoppers or customers).
- Skills still being learned listed as mastered. Remove or move to a "Currently learning" line.
- Date ranges that overlap in a way an employer will question.
- Banned phrases from the Voice Rules.

**ATS check** (ATS means applicant tracking system, the software that reads resumes before a human does)
- Single column layout. No text in tables, text boxes, headers or footers.
- Standard section names: Summary, Skills, Experience, Education (plus Projects or Certifications if needed).
- Real bullet points, one achievement per bullet. No run-on paragraphs of labels.
- Skills as plain keyword lists, using the words job posts use. No invented skill names.
- No emoji or icons (they turn into garbled characters).
- Contact links (email, LinkedIn, portfolio) written out as visible text. Other links can sit behind company and brand names.
- Dates in one consistent format (Mon YYYY to Mon YYYY, or YYYY to Present).
- File saved as PDF with real text (not an image), named `First Last Resume [Version].pdf`.

**Readability check**
- Length: 1 page by default, since selective versions fit. 2 pages max, only for senior roles where page two carries real proof. Never a second page holding a few lines: trim or tighten instead.
- Jargon load. If more than a few bullets start with the same big verb (Architected, Engineered, Orchestrated), vary them and use plain verbs too (Built, Ran, Grew, Cut, Launched, Wrote).
- Every bullet answers "so what" with a number, a scale, or a result.

Show the audit as a short list, then fix it.

## Step 2: Write the content

**Header:** Name. One contact line: City or "Remote" plus time zone, email, phone (optional), portfolio link, LinkedIn.

**Headline:** the target title for this track, in the words job posts use. One line.

**Summary:** 2 to 3 sentences. Who they are, what they are great at, proof in one number, what they want next. Tone follows the Voice Rules (warmer for passion industries).

**Skills:** 3 to 4 short labeled lines, each a comma list of real tool and skill keywords.
Example shape: `Design: Photoshop, Illustrator, InDesign, Figma`

**Experience:** reverse date order by default. For each role: Title, Company, Location or Remote, Dates. Then 3 to 6 bullets.
Bullet formula: **Action verb + what you did + tool or method + number or scale + result.**
Example: "Built a product photo pipeline in Photoshop and AI tools that produced 300+ room renders for the online store."

**Education and training:** degree, school, year, honors. Add relevant certificates or courses.

Only reorder roles out of date order if a track truly needs it, and keep dates visible so it never looks hidden.

## Step 3: Design it as an HTML artifact

Build the resume as one HTML page so the person can see it, comment, and ask for changes before exporting:

- Letter size page (8.5 x 11 in) with `@page { size: letter; margin: 0.5in; }` and print styles.
- One column. Clean sans serif or serif body at 10 to 11pt, name at 20 to 26pt. One accent color max.
- Section headings as real `<h2>`, bullets as real `<ul><li>`, so the PDF text stays readable to ATS.
- No background images, no icons, no multi column grids for content.
- Hyperlink every named company, client, brand, school, social account and live proof page (store, blog, demo site) so a recruiter can click straight to it. Keep the visible text readable on its own. Open each link first: never link a dead domain, a password page, or a site the person doesn't control yet (leave a planned portfolio domain off until it's live).
- Publish it with the Artifact tool (private by default) so they can open it again and share it.

If the person wants a fancier "designer" resume, make it as a **second** file and still send the plain ATS version to job forms. Use the designed one for email, portfolio sites and networking.

**Build every version from one bullet library.** Keep each proof bank win as named bullets, with a long and a short variant, and compose each version from them in a small script. A corrected number then changes in every version at once, and versions cannot drift apart.

## Recruiter review (before export)

Run this for every new or reworked set of versions. Open ChatGPT in a Temporary chat with personalization off and ask it to act as a recruiter. Give each version with its target role, leaving out the phone number and other private details. For each version ask: is the headline and summary aimed at that role, which bullets to cut, the best order of roles and bullets, which bullets to reword with that role's keywords (no new facts), which skills to drop, and the target length.

Judge every suggestion. Keep cuts and reorders that sharpen the fit. Reject added claims, tools or numbers, titles that undersell the person's level, and rewordings that only change words. Rebuild, recheck page counts, then export.

## Step 4: Export to PDF

- **Cloud session with a shell:** render the HTML with Playwright (`page.pdf({format: 'Letter', printBackground: true})`), then check the PDF text with `pdftotext` to be sure the words come out in the right order and nothing is garbled. In the print HTML, load static font files (for example from the npm @fontsource packages) rather than Google's variable fonts: variable fonts embed as Type 3 and make the PDF several times bigger.
- **No shell:** tell the person to open the artifact, press Cmd+P (Mac) or Ctrl+P (Windows), choose "Save as PDF", margins "None" or "Default", and turn on "Background graphics".
- Save to their resumes folder with the naming rule from the Career Profile, then update the Asset Library table in the profile with the new link and date.

## Step 5: Tailor to one job (when asked)

1. Read the job post (or the job-screening card).
2. Pull the top 10 to 15 keywords and must-have skills.
3. Mark which ones the resume already shows, which it shows in other words, and which are true but missing.
4. Edit only the summary, skills order, and bullet order and wording. Never add a skill or number that is not in the proof bank.
5. Tell the person the match before and after in one line (example: "12 of 15 key terms now show up, up from 7").
6. Save as `First Last Resume [Company].pdf`.

## Step 6: Hand off to job-board-profiles

After a new or changed track version, offer to run **job-board-profiles** so LinkedIn, Indeed, ZipRecruiter and Upwork match the new resume. A one-job tailored copy does not need a profile update.

## Rules

- Never invent experience, numbers, titles, or degrees.
- Follow the core no long dashes rule, then every Voice Rule in the Career Profile, including banned phrases and punctuation.
- Internal-only terms from the profile never appear on a resume.
- Never put a full street address, birth date, photo (US roles), or ID numbers on a resume.
- When done, tell the person what changed in plain words and attach or link the actual file.