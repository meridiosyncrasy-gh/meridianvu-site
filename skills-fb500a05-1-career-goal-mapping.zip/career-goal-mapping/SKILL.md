---
name: "career-goal-mapping"
description: "Step 1 of 7 in the job search skill set. Interviews a person about where they are now and where they want to go, then builds or updates their Career Profile, the one doc every other job search skill reads. Mines what the person already gave before asking: past application emails, Drive folders, old resumes, cover letters and goal docs, and records each source so later skills can look things up. Covers career tracks (dream role, replacement role, side work), money floor and pay targets, work authorization, remote and schedule guardrails, the Yes list and No list, passion industries, a proof bank of real accomplishments with locked numbers, skill gaps, writing voice rules, and an index of their resumes and portfolios. Use for \"map my career goals\", \"build my career profile\", \"what jobs should I go for\", \"update my salary floor\", \"add this win to my proof bank\", or when any other job search skill finds no Career Profile. Works for any person and any field."
---

# Career Goal Mapping

This is step 1 of the 7 skills that run a full job search with Claude:

1. **career-goal-mapping** (this one): who you are, what you want, what you will not do.
2. **resume-builder**: resume versions built from your proof bank.
3. **portfolio-builder**: case studies, portfolio site, spec projects.
4. **job-board-profiles**: LinkedIn, Indeed, ZipRecruiter and Upwork profiles that match the resume and portfolio.
5. **job-screening**: finding jobs and deciding which are worth it.
6. **application-writer**: cover letters, form answers, applying, tracking.
7. **interview-prep-follow-up**: prep packs, pay talks, follow up emails.

Every other skill reads the **Career Profile** this skill makes. If it is wrong, everything downstream is wrong, so take the time here.

## Core rule: no long dashes (applies to every person)

This rule is part of the job search skill set and does not change per person. Everything this skill writes follows it: the Career Profile, the Career Map, the application log it sets up, and the messages Claude sends the person. Write the person's proof bank wording and voice rules without long dashes too, even when they type one.

- Never use the em dash (—) or the en dash (–). The plain hyphen (-) is fine inside words like "full-time" or "30-60-90".
- Rewrite instead of swapping one dash for another:
  - Two related ideas become two separate sentences.
  - A label and its detail use a colon ("Pay: $85K to $95K").
  - Side-by-side items, or a title and a name, use a vertical bar ("Designer | Acme Co").
  - Ranges use "to" ("Jan 2024 to Mar 2026", "$78K to $96K").
- Text pulled from job posts, old resumes, templates, ChatGPT or any other tool gets rewritten the same way before it goes into anything this skill makes. Direct quotes from a job post on a screening card are the only exception.
- Before showing, saving or sending anything, search it for "—", "–", "&mdash;", "&ndash;", "&#8212;" and "&#8211;". The count must be zero.

The person's other style preferences (words to avoid, tone, greetings) come from the Voice Rules in their Career Profile and change per person.

## Where the Career Profile lives

- **Default:** a doc named `career-profile.md` in the person's Claude project (use the Projects tool `project_write`). Also make `application-log.md` there if it does not exist (the template is in the application-writer skill).
- **No project attached:** make it a Claude Doc (living doc) if the Docs tool is there, otherwise a markdown file the person keeps and attaches next time. Tell them where it went in one plain sentence.
- **Updating:** always read the current profile first, change only what changed, and add a line to the Change Log at the bottom with the date.
- **Project files can't be edited in place:** add the new version as a file with the same name, confirm it saved whole, then remove the old copy so only one profile exists.
- **Gaps found later:** when any later skill has to ask the person something an earlier source could have answered, treat it as a profile gap. Add the answer to the right section and its source to the Source Library, so it is never asked again.

## How to run it

### Step 1: Gather before asking

Before asking the person anything, collect what already exists so you only ask about gaps. Search every place they have given you, not just what is attached:

- Their current resume(s): attached files, Google Drive (search titles with "resume"), the Indeed connector (`get_resume`), or LinkedIn if they paste it.
- **Past application history in email.** Search their inbox (Gmail connector, or the browser) for application receipts and replies: "thank you for applying", "application received", "your application", interview invites, rejections and recruiter messages, plus senders like Indeed, LinkedIn, ZipRecruiter, Upwork, Workable, Greenhouse, Lever and Ashby. Build an application history file (company, role, date, board, outcome) and pull out the facts the forms already asked, such as work authorization and sponsorship, pay numbers they entered, titles they went for, and how far each one got.
- **Drive folders and connected computer folders.** Look for application folders by company, cover letter folders, portfolio drives, case studies, references, and archive folders of old goal docs. Read the old cover letters for proof stories and voice.
- Any old "career plan" or goal doc they wrote, including AI chat exports.
- Their memory, project docs and past chats in Claude (search past conversations for their job search).

Pull facts out of these into a draft profile. Mark anything you inferred (not stated) with `(check)` so the person confirms it. List every source you found in the profile's **Source Library** section with what it holds and where it lives, so every later skill can look things up instead of asking again.

### Step 2: Interview for the gaps

Use AskUserQuestion, max 4 questions per round, plain words, with options. Ask only what Step 1 did not answer. Cover these areas in this order:

1. **Right now:** current job and income, why they are looking, how urgent (need income in 30 days vs slow upgrade).
2. **Money:** the monthly survival floor (the number the household cannot go under), and target pay for each track. Convert between hourly, monthly and yearly for them (hourly x 2,080 = yearly).
3. **Tracks:** most people need 2 or 3 at once:
   - **Track 1, Dream role:** the long-term target. Titles, company types, pay band.
   - **Track 2, Replacement role:** a solid job that pays the bills and builds proof toward Track 1.
   - **Track 3, Side work:** freelance or contract work that adds income or fills a portfolio gap.
   One track is fine if that is honest. Do not force three.
4. **Guardrails:** remote, hybrid or onsite; time zone; travel they are OK with vs not; W2 vs 1099 vs contract; company size; hours.
5. **Yes list and No list:** duties and setups they want, and deal breakers (examples: managing people, being the only designer with no strategy, office for office's sake, companies that ban AI tools, commission only pay).
6. **Passion industries:** industries they light up about. These change the tone of their applications (warmer and more personal).
7. **Proof bank:** for each real win, get the plain wording, the number, the time frame, and a link to proof. Ask "how would you say this out loud?" so the wording sounds like them.
8. **Voice rules:** words and phrases they would never say, punctuation they hate, greeting rules, internal-only nicknames that must never show up in applications.
9. **Vision:** where they want to be in 5 and 10 years, one or two lines each.

### Step 3: Pressure test it

Before saving, check the profile and tell the person plainly about anything that does not add up:

- A track's pay band is below the survival floor.
- A target title does not match their proof bank (they need a portfolio piece or a bridge role first).
- Two proof bank numbers disagree across their old resumes (pick one and lock it).
- A stat that merges two separate wins into one bigger claim. Split it into two true claims.
- A skill listed on their resume that they are still learning. Move it to "Learning now".
- Hidden conflicts, like "remote only" plus a dream company that is office first.

Suggest the fix, then save.

### Step 4: Save and hand off

Save the Career Profile, then tell the person in two or three plain sentences what their tracks and floor are, and what the best next step is (usually resume-builder, or portfolio-builder if a track has no proof yet).

Offer a one page visual **Career Map** artifact (tracks, pay bands, Yes and No lists, 5 and 10 year vision) if they want something to look at. Build it as an HTML artifact.

## Career Profile template

Copy this exactly. Keep headings so other skills can find sections.

```markdown
# Career Profile: [Name]
Last updated: [date]

## 1. Basics
- Name used on applications:
- Location and time zone:
- Contact line for resumes (city or "Remote", email, portfolio link, LinkedIn):
- Work authorization: (citizen or permanent resident / visa type; needs sponsorship yes or no). Application forms ask this every time, so always fill it.
- Work setups OK: (remote / hybrid / onsite)
- Employment types OK: (W2 full time / W2 contract / 1099 / part time)

## 2. Right Now
- Current role(s) and income:
- Why looking:
- Urgency: (need income by [date] / steady upgrade)

## 3. Money
- Survival floor: $___ per month ($___ per year, $___ per hour)
- Will not apply under: $___ per hour or $___ per year
- Pay rule for forms: ask in the upper middle of a posted range. If nothing is posted, research the company first.

## 4. Tracks
### Track 1: [name] (Dream role)
- Target titles:
- Ideal companies or environments:
- Pay band:
- Resume version to use:
- Portfolio or case study to lead with:
- What proves I am ready:
- What is still missing:
### Track 2: [name] (Replacement role)
(same fields)
### Track 3: [name] (Side work)
(same fields)

## 5. Guardrails
- Remote rule:
- Time zone rule:
- Travel in scope / out of scope:
- Schedule limits:
- Company size or type preferences:
- Post-level skips (examples: a post that already shows a hire, too many people already invited to interview):

## 6. Yes List (want more of)
-
## 7. No List (deal breakers)
-

## 8. Passion Industries
- Industries:
- Tone rule: warmer, more personal tone for these, even on full time roles.

## 9. Proof Bank
| Win (in my words) | Number | Time frame | Proof link | Tracks it serves | Locked wording or notes |
|---|---|---|---|---|---|

## 10. Skills
- Strong now:
- Learning now (never list as mastered):
- Gaps per track:

## 11. Voice Rules
- Tone:
- Never say:
- Punctuation rules: (em dashes and en dashes are never used; this is built into every job search skill)
- Greeting rule:
- Internal-only terms (never in anything an employer sees):

## 12. Asset Library
| Asset | Version or track | Link | Last updated |
|---|---|---|---|
(resumes, portfolios, case studies, references doc, headshot, LinkedIn)

## 13. Search and Apply Settings
- Job boards (LinkedIn, Indeed, ZipRecruiter, Upwork, others) and which are connected:
- Search titles per track:
- Locations:
- Autonomy level: 1 Review (I check every list and application) / 2 Batch (one yes per run) / 3 Autopilot (Claude screens and applies, then sends a digest). New users start at 1. job-screening and application-writer offer the next level once my reviews show few changes.
- Daily application cap at Autopilot: (default 10)
- Weekly Upwork Connects budget:
- Files naming rule:

## 14. Vision
- 5 years:
- 10 years:

## 15. Source Library (check here before asking the person anything)
| Source | What is there | Where |
|---|---|---|
(email application history, Drive or computer folders, archived goal docs, project files, artifacts, live sites)

## Change Log
- [date]: [what changed]
```

## Writing rules for this skill

- Write the profile in the person's own words where possible. It is their doc, not a report about them.
- Follow the core no long dashes rule in the profile and every message.
- Never invent a number. If they do not know it, write `(unknown)` and move on.
- Never put ID numbers, bank details, or passwords in the profile. Work authorization status (citizen, visa type, sponsorship) is fine; document numbers are not.
- Keep internal-only nicknames (like a private name for a track) clearly marked so the other skills never use them in employer-facing writing.

## Review cadence

Suggest a quick re-run every 1 to 3 months, after any new job or contract, after a big win (add it to the proof bank), or when the person's money or location changes.