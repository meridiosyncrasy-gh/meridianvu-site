---
name: "job-screening"
description: "Step 5 of 7 in the job search skill set. Finds jobs on LinkedIn, Indeed, ZipRecruiter and Upwork through their connectors (browser as backup) and screens each one against the Career Profile tracks, resume versions and portfolio pieces from steps 1 to 3. Each job gets a screening card: remote check, company, duties, track fit, pay vs the floor, safe form pay, skill gaps, No list conflicts, resume, portfolio piece, lead role and an Apply, Maybe or Skip call. Hands the Apply list to application-writer. Uses the shared autonomy ladder: new users review every list, and Claude offers more autonomy once the person stops changing its calls, up to Autopilot where Claude screens and applies with no input. Use for \"find me jobs\", \"check this job post\", \"is this a good fit\", \"what salary should I put\", \"which resume for this\", \"run my daily job search\", or a pasted job link. Works for any person and field."
---

# Job Screening

Step 5 of 7 in the job search skill set: career-goal-mapping, resume-builder, portfolio-builder, job-board-profiles, job-screening, application-writer, interview-prep-follow-up.

## Core rule: no long dashes (applies to every person)

Everything this skill writes follows it: cards, ranked lists, log entries and messages to the person.

- Never use the em dash (—) or the en dash (–). The plain hyphen is fine inside words like "full-time".
- Rewrite instead of swapping: two ideas become two sentences, a label and detail use a colon ("Pay: $85K to $95K"), side-by-side items use a vertical bar ("Designer | Acme Co"), ranges use "to".
- Text pulled from job posts or other tools gets rewritten the same way. Direct quotes from a job post on a card are the only exception.
- Before showing or saving anything, search it for "—", "–", "&mdash;", "&ndash;", "&#8212;" and "&#8211;". The count must be zero.

Other style rules come from the Voice Rules in the Career Profile.

## Before you start: load steps 1 to 3

Screening is only as good as what the first three skills built. Read, in this order:

0. **Find the Career Profile before saying it is missing.** It may live in a project's files, a Drive folder, a Claude artifact, or another Claude account the person uses. Check every place the person keeps work, including any registry of their files or accounts. Only run career-goal-mapping when it truly does not exist.

0b. **Sync the profile with the newest portfolio first.** This skill runs after portfolio-builder, so the live portfolio (site, case studies, resume page, services and prices) is often newer than the profile. Compare the portfolio's numbers, links, offers, prices and resume headline with the profile's Proof Bank, Asset Library, Money and tracks. Update the profile where the portfolio is newer, add a dated Change Log line, and keep locked wording rules. Where two portfolio pages disagree with each other, use the one with the newest dated basis and flag the other page for a fix. Then screen against the updated profile.

0c. **Look before you ask.** Before asking the person anything, check the profile's Source Library (past application emails, Drive folders, archived goal docs, project files). If the answer was given earlier, use it and add it to the profile. If the profile has no Source Library, run career-goal-mapping's gather step to build one.

1. **Career Profile** (`career-profile.md`, from career-goal-mapping). Pull: tracks (target titles, pay band, ready vs missing), survival floor and "will not apply under", minimum client size and its exceptions, full-time conditions, guardrails, Yes and No lists, passion industries, Skills (strong vs learning), published prices, Search and Apply Settings (including the name to use on each board), and the **Autonomy level**. If there is no profile, run career-goal-mapping first.
2. **Resume versions** (from resume-builder): the Asset Library rows for the master and each track version. A track with no resume version can still be screened, but flag it and offer resume-builder.
3. **Portfolio pieces** (from portfolio-builder): Asset Library rows and which track each piece proves. A track with no proof gets a lower ceiling: Maybe at best, unless the post is clearly entry level for that track.
4. **application-log.md**: every job already screened or applied to, plus the Review Tracker (see the autonomy ladder below).

## Where to search: connectors first, browser second

Tool names change, so go by each tool's description. Check what is loaded at the start of a run.

| Board | Use the connector for | Use the browser for |
|---|---|---|
| LinkedIn | Job search and details, if a job seeker connector is loaded | Search when no connector is loaded. Easy Apply is handled by application-writer |
| Indeed | `search_jobs`, `get_job_details`, company data and salaries | Full post when the connector fails (in Chrome) |
| ZipRecruiter | `search_jobs` | Full post details when the connector result is thin |
| Upwork | Find jobs, saved jobs, job and client details (client history, spend, hire rate, Connects cost) | Nothing for screening |

- If a board in the person's settings has no connector loaded, check ListConnectors once. If it exists but is not connected, offer it with SuggestConnectors one time, then use the browser and keep going. Never stop the run over one board.
- Browser rules: sign in with the person's Google option if needed. Never type a password, never create an account, never solve a CAPTCHA. If one appears, ask the person to clear that one step (at Autopilot, skip that board and list it in the digest).
- "The browser" in this skill always means the person's own Chrome (Claude in Chrome), where they are signed in. Never use a separate built-in browser for job boards or company application pages, even when it is the session's preferred browser: Cloudflare and other bot checks fail there.
- Search every target title of every track, using each track's own titles and pay band. Filter to the last 24 hours on daily runs, last 30 days max on first runs.

## Mode A: Check one job post

The person pastes a link, job ID or post text.

1. Get the full post through that board's connector, or the browser.
2. Research the company: connector company data, the company site, and a quick web search for size, funding, news and how they talk about AI. Upwork: client history, reviews, hire rate and average rate paid.
3. Fill the screening card.

## Mode B: Daily search

1. Search each board as above, per track.
2. Drop: anything in the application log, posted over 30 days ago, a hard No list hit, below "will not apply under", or a post-level skip from the profile's Guardrails (for example a post that already shows a hire or offer).
3. Write a card for each survivor, then a ranked list: Apply first (Track 1, then 2, then 3), then Maybe.
4. Follow the autonomy level for what happens next.

## The screening card

Answer every line. Keep it scannable.

```markdown
## [Job title] | [Company]
Link: [url] | Posted: [date] | Source: [board] | Via: connector / browser

**Call: Apply / Maybe / Skip** (one sentence why) | Confidence: High / Medium / Low

1. Remote check: Fully remote / Hybrid / Onsite / Unclear. Quote the line that proves it. Time zone or travel asks.
2. The company: 2 to 3 lines on what they do and who they serve.
3. Key duties: bullets, each with how it serves the company's customers or goals.
4. Track fit: Track 1, 2, 3 or none, and why. Name the profile's "what proves I am ready" items this job matches.
5. Pay check: posted pay | yearly or hourly equivalent | vs floor and track band | safe number for the form | number to aim for live.
6. Skill gaps: what they want that the Skills section or proof bank cannot prove yet.
7. Career Path gaps: clashes with guardrails, Yes list or No list.
8. Red flags: (list below)
9. Use this resume: [Asset Library version], tailor: yes/no
10. Lead with this role: [title at company] because ___
11. Feature this portfolio piece: [Asset Library name + link]
12. Cover letter or proposal angle: the one proof bank story that best matches their top need.
```

Confidence is High only when remote status, pay (posted or researched) and track fit are all clear. Any "Unclear" or "not found" line makes it Medium or Low.

## Pay rules

- Hourly x 2,080 = yearly. Yearly / 12 = monthly. Compare with the floor.
- Posted range: suggest the upper middle for the form. High enough to signal level, not so high a filter auto rejects it (posted $78K to $96K, put $88K to $92K).
- No range: research first (connector salary data, company size, funding, HQ location), then a number inside what that company plausibly pays.
- Upwork: compare the budget or hourly range with the track's rate, and note the Connects cost.
- Minimum client size (for example "$1,000 a month") usually means ongoing or spaced-out work. A one-off below it can still be Apply when it is quick to deliver (hours, not weeks, often because a skill already does most of it) and the effective hourly rate clears the floor. Read the profile's exceptions before skipping a small job.
- Proof-building work: a job that would add a case study for an offer with thin proof (often the person's highest priced offer) can be Apply even when small. Say so on the card.
- Full-time roles: apply every condition the profile sets (example: pay floor AND a chosen industry). Missing any one is a Skip.
- Way under the floor: Skip, or Maybe only if the person said they need fast income. If the real rate turns up later far lower than expected, recommend walking away unless it can nearly double, and offer a polite walk-away note (interview-prep-follow-up has the template).
- Keep "safe for the form" and "aim for live" as two separate numbers.

## Red flags

- Says remote but asks for office days, a local address or "onsite for some projects".
- Pay below the floor, commission only, or "unlimited earning potential" with no base.
- Duties on the No list (example: managing people, HR reviews, generalist "do everything" roles).
- Staffing agency posts where the real employer and pay are unclear. Ask who the employer of record is.
- Time zone that clashes with the guardrails.
- A ban on AI tools, if the person's work relies on them.
- Reposted for months, or vague duties with a huge title.
- Upwork: client with no payment method verified, no hires, or asks to move off platform.
- Already hired or offered on this post (Upwork job activity shows hired or offered above 0). Small one-person jobs are usually filled by then. Skip when the profile says so, and recheck right before applying.
- Requests for bank details, ID or money before an offer. Call it a scam plainly.

## Picking the resume and portfolio

- Match the track first, then the level: execution roles get the execution version, senior or strategy roles the senior version, mixed roles the hybrid.
- Lead with the role whose duties overlap the post most, even if it is not the most recent.
- Feature one portfolio piece, the one closest to their top duty. A mini case study often beats a big general portfolio.

## The autonomy ladder (shared with application-writer)

The level lives in the Career Profile, Search and Apply Settings: **Autonomy level: 1 Review / 2 Batch / 3 Autopilot**. New people start at 1. Both skills read the same level.

| Level | Screening | Applying |
|---|---|---|
| 1 Review | Claude shows the cards and ranked list. The person picks what moves on. | application-writer drafts, fills and stops before submit for each job |
| 2 Batch | Claude shows one ranked list per run. One yes moves the whole Apply list on. | application-writer shows one batch and submits on one yes |
| 3 Autopilot | Claude screens with no check-in and sends High confidence Apply jobs straight to application-writer | application-writer submits with no check-in, then sends a digest |

**Autopilot limits (always on):** only High confidence Apply calls (Maybe always waits for the person), pay at or above the floor, the daily application cap and weekly Upwork Connects budget in the profile (defaults: 10 per day, ask before spending Connects if no budget is set), and every hard stop in application-writer.

### Review Tracker

At levels 1 and 2, log how the person reacted to each call in the Review Tracker section of the application log:

- **Agreed:** kept Claude's call.
- **Overruled:** changed it (Skip to Apply, Apply to Skip, or a different track or resume).

When the person overrules a call and says why, turn the reason into a general rule in the Career Profile (Money, Guardrails or Search and Apply Settings) with a Change Log line, and re-check that run's other calls against it.

### When to offer the next level

Check after every run. Offer to move up one level when all of these hold:

- At least 10 calls reviewed at the current level.
- At most 1 Overruled in the last 10, and none in the last 5.
- application-writer's readiness check also passes (its letters are going out with no or light edits).

Clear chat signals count too ("looks good, just send them", "you don't need to ask me each time").

How to offer: one short message. Say what you noticed (for example "you kept 10 of my last 10 calls"), what the next level does, what still stops and comes back to them, and that saying "back to review" drops the level at any time. Ask yes or no. Never move up without a clear yes, and update the profile's Autonomy level and Change Log when they say yes.

### When to step back down

Drop one level right away, and say so in one line, when: the person overrules a call made at level 2 or 3, they say a submitted application should not have gone out, a track, floor or No list changes in the profile, or a new board is added.

## Upwork catalog demand notes

Upwork searches double as research for the person's Project Catalog (job-board-profiles builds the projects).

- While screening Upwork, note small fixed-price asks that match a track and keep repeating: what the client wants, budget, proposal count and whether it already hired. Keep a running tally in the Career Profile under Upwork demand.
- When an ask shows up 3 or more times in a month and the person has no catalog project for it, suggest one in the run summary: the offer, a rough tier and price, the proof bank story that backs it, and which website service it leads to. If the person has said yes to catalog projects, hand it to job-board-profiles to draft and build.
- If live catalog projects get views but no orders for a month, flag them for a price or scope check.

## When done

- Level 1: give the cards or ranked list and one plain line on what to do next.
- Level 2: give the ranked list and ask for one yes to send the Apply list to application-writer.
- Level 3: hand the Apply list to application-writer, and fold the results into its digest (applied, waiting on Maybe, skipped and why, boards that needed a sign-in).
- Every level: add Skip results to the log with status "Screened: Skip" so they are never checked again.