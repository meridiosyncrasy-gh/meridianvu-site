---
name: "application-writer"
description: "Step 6 of 7 in the job search skill set. Writes and sends job applications in the person's own voice from their Career Profile: cover letters, form answers, Upwork proposals and recruiter messages. Applies through the board's own connector where it can submit (Upwork proposals) and the browser for the rest (LinkedIn Easy Apply, Indeed, ZipRecruiter, company sites), then keeps the application log. Uses the shared autonomy ladder with job-screening: new users review every application before it goes out, Claude tracks how much they edit and offers more autonomy once drafts go out unchanged, up to Autopilot where Claude applies with no input and sends a digest. Hard stops always come back to the person. Use for \"write a cover letter\", \"apply to this job\", \"answer these questions\", \"write an Upwork proposal\", \"apply to my Apply list\", \"log this application\", or \"what have I applied to\". Works for any person and field."
---

# Application Writer

Step 6 of 7 in the job search skill set: career-goal-mapping, resume-builder, portfolio-builder, job-board-profiles, job-screening, application-writer, interview-prep-follow-up.

## Core rule: no long dashes (applies to every person)

Everything this skill writes follows it: letters, form answers, proposals, messages, file names, the log and messages to the person.

- Never use the em dash (—) or the en dash (–). The plain hyphen is fine inside words like "full-time".
- Rewrite instead of swapping: two ideas become two sentences, a label and detail use a colon, side-by-side items use a vertical bar ("Designer | Acme Co"), ranges use "to".
- Text pulled from posts, old resumes or other tools gets rewritten the same way.
- Before showing, saving or sending anything, search it for "—", "–", "&mdash;", "&ndash;", "&#8212;" and "&#8211;". The count must be zero.

Other style rules come from the Voice Rules in the Career Profile.

## Before you start

1. Read the **Career Profile**: Voice Rules, Proof Bank, Asset Library, Search and Apply Settings, and the **Autonomy level**. If missing, run career-goal-mapping first.
2. Read `application-log.md`. If the job is already there, stop and say so.
3. Get the job's screening card. If there is none, run job-screening Mode A first. Never apply to a Skip unless the person says to.
4. Re-open every post before drafting. Check it is still open, still the same job, and passes the profile's post-level skips. Example: a post that already shows a hire or offer (Upwork jobActivity totalHired or totalOffered above 0) is skipped when the profile says so, and flagged to the person when the profile is silent, before any Connects are spent.
5. Use live numbers, not the log: the Connects balance from the connector, the current posted pay, and any scope attachment (open and read it before writing).
6. Look before you ask. Any form question the profile doesn't answer (work authorization, past pay, references, start date) gets searched in the profile's Source Library first: past application emails, earlier cover letters and form answers in Drive, archived goal docs, past chats. Use what was given before and add it to the profile. Ask the person only when no source has it.

## Running a batch (an Apply list)

- Pull every post first, then draft all, then fill forms, then log. One blocked job never stops the rest.
- Save the whole batch in one doc (status table at the top, one section per job) so the person reviews everything in one place, and link it from each log row.
- Bring every question back in one message at the end: hard stops, anything the person must click, and the send approvals.

## Cover letter structure

About 250 to 380 words, 4 to 5 short paragraphs.

- Write one whenever the application has a cover letter field, even an optional one, and always run it through the ChatGPT copy pass below. An optional field left blank is a missed chance.
- Match the person's own past letters (Source Library: cover letter folders, sent applications) for greeting, paragraph count, sign-off and how links are labeled. The Voice Rules win where they differ.
- Links: follow the Portfolio links section below.
- When a board has no letter field (some Indeed forms), save the finished letter in the batch doc anyway for interview prep.

1. **Greeting:** "To the [Company] Team," unless the Voice Rules say otherwise. A hiring manager's name only if it is in the post.
2. **Hook:** passion for the industry or problem the company solves, plus who the person is in one line. Show love for the industry, not fan talk about the company.
3. **Main proof:** the proof bank win matching the top duty, as a mini story with its number, then one sentence linking it to what they need.
4. **Second proof:** a different side of them matching another duty, plus one line on how they think or work.
5. **Optional range paragraph:** only for roles that want breadth.
6. **Close:** forward-looking fit, echo one phrase from the post or values, a light call to talk. No begging, no salesy push.
7. **Sign off:** "Best," or "Best regards," then name, email, phone (optional), then 1 to 3 labeled links.

Tone follows the Voice Rules. Default is warm, plain and personal, like the person talking. Passion industries get extra personality. Corporate roles get a bit more polish but still sound human.

## Upwork proposals

- Open with the client's problem in their words, not with "Hi, I am".
- One proof bank story that matches, with its number, and one line on how you would start.
- Answer every screening question the client set. Attach the featured portfolio piece.
- Bid inside the track's rate. Note the Connects cost in the log.
- Stay under about 150 words unless the job is large or the client asks for a list of answers.
- If the client asks the proposal to open with specific points, open with exactly those.
- Fixed price asked in the text but the post is set up as hourly: put the hourly rate in the bid field and the fixed prices and milestones in the proposal text, and say so in the log.
- Keep fixed prices and milestones consistent with the person's published packages when they have them.
- Platform honesty: only claim tools listed under the person's strong skills. For a tool the client names that is not there, say it is new to them, using the gap line rule below.
- First proposal through the connector: Upwork asks the person to confirm its "payments only through Upwork" policy once. Ask for that together with the first send approval, then record it.
- The connector keeps one proposal preview open at a time, and each expires in about 15 minutes. Keep every proposal's text in the batch doc, then rebuild and send each one right after its approval. Send without a boost first, then run the boost check below.

### Boost check (after every Upwork batch goes through)

Right after the proposals send, show one table with every proposal sent: job, bid, Connects spent, and a boost call. Read the boost block from each proposal's preview (current top bids, minimum bid, available or not). The calls:

- **Worth it:** fewer people have boosted than there are paid slots, so the minimum bid wins a top slot (usually 3 to 5 Connects). Name the exact amount.
- **Not worth it:** the top bids are high (about 20+ Connects, or more than the proposal itself cost), or the bid would eat most of the remaining balance.
- **Not available:** the person doesn't meet the client's preferred qualifications (often Job Success Score or earnings). Say which ones, and that the proposal still went through.

Under the table, give the remaining balance and one line on why each worth it call wins a slot. Add the worth it boosts only after the person says yes (a profile boost budget counts as a yes at Autopilot). Re-check bids before adding, since they change. Add each with edit plus boost_connects, then read it back (boosted, connectsBid) and log the Connects. Applies to any bidding board with paid placement.

## Form question answers

- First person, 80 to 180 words unless the form sets a limit. Count and stay under limits.
- "Why this company or role": industry passion + one matching proof + what they want to build there.
- "Tell us about a project": short STAR story with a number.
- Salary fields: the "safe for the form" number from the screening card.
- "How did you hear about us": the true source.
- Every free-text answer ends with a portfolio link (see Portfolio links below).
- Long answers: put a blank line between paragraphs, and between list items when an answer covers several things, so it's easy to scan. Indeed and most ATS text boxes keep line breaks.
- End every free-text answer with the most relevant portfolio link from the profile (a case study, portfolio page or services page), even when the cover letter already links it. Each answer may be read on its own. Yes or no questions get one too when a page fits, such as a services page for terms and schedule. Open each link once to confirm it loads.
- Eligibility questions (work authorization, location, schedule): from the Career Profile, then its Source Library. If no source has it, fill everything else, leave that field, ask once, and save the answer to the profile so it never comes up again.
- Demographic and voluntary disclosure questions: leave for the person, or "decline to answer" only if the profile says so.

## Portfolio links (letters, forms, proposals)

Use this whenever the person has a portfolio: a site or pages built with portfolio-builder, or one they already had. If they have none, skip it and offer portfolio-builder once.

1. **Build a link map** at the start of a batch from the Career Profile Asset Library and the live site: each case study, portfolio page, services or pricing page and resume page, with the track or proof story it backs. Open each link once to confirm it loads. Use only current links the profile names, never retired ones (old Drive or Docs links, drafts, password-protected pages).
2. **Cover letters:** after the sign-off, add 1 to 3 labeled links that back the letter's main and second proof. Label them the way the person's past letters do (for example "[Case study name] | [Client]:" then the URL).
3. **Every free-text form answer** ends with the most relevant link on its own line, even when the cover letter already links it, because each answer may be read alone. Match the link to the answer:
   - A project or workflow story gets its case study.
   - A "why us" or passion answer gets the closest brand or industry page.
   - Terms, schedule or availability questions get the services page.
   - Anything general gets the portfolio home.
   Yes or no questions get one too when a page fits.
4. **"Link something you built" questions:** one line on the tools and the result, then the link under it, with a blank line between items.
5. **Upwork proposals:** attach the matching portfolio items from the profile. Put a link in the text when it backs the proof story or the client asks for samples.

## Truth and voice check (before anything is shown or sent)

- Every number and claim is in the proof bank with its locked wording. No merged stats. Nothing from "Learning now" claimed as mastered.
- No long dashes, none of their banned phrases, no internal-only terms.
- No filler ("I am writing to express my interest", "fast-paced environment", "team player").
- **Gap lines** (a tool, scale or result the person can't claim yet): name the gap in one short clause, then pivot with "but" to the closest real strength. Never end the sentence on the honesty itself ("and I'd rather say that up front", "than oversell it"), because that leaves the reader on the weakness. Examples:
  - "Keap and Otter would be new platforms for me, but I am no stranger to learning new software in my 11 years of online web and marketing work."
  - "I haven't run an indexing recovery at 130,000 products, but I am very familiar with large catalogs and tackling solutions for scale."
  The pivot must be true and backed by the profile (years of experience, proof bank wins, Skills).
- **Proof in the text, not behind a link.** When a job is about a specific result (search traffic, sales, hours saved), put the person's matching numbers in the letter, proposal or answer itself, in the client's terms. A link backs the claim up but never replaces it, because many readers never click. If the proof bank lacks a number the job clearly asks for, check the person's connected data first (store analytics, Search Console, ad accounts), add what's true to the proof bank with its source and date, then use it. Example: a page migration protecting about 5,800 yearly search clicks gets the person's own stores' yearly search visits named in the proposal.
- Company name and job title right everywhere, with no leftovers from another letter.

## ChatGPT copy pass (letters, proposals, long form answers)

Claude drafts, ChatGPT reviews as the hiring manager or client, Claude judges.

1. Open ChatGPT in a Temporary chat (`chatgpt.com/?temporary-chat=true`) so memory and personalization stay out. In a batch, send all drafts in one prompt, labeled by job.
2. Paste the job post's key duties with each draft. Role: the hiring manager for this post (or the Upwork client). Rules: no new facts or numbers, every number kept exactly, no em or en dashes, plain human words, keep the person's voice and word limits. Ask what a reader would think in one line, then an exact replacement or KEEP for each paragraph.
3. Claude keeps only changes that are clearer and still true, then reruns the truth and voice check above.
4. Short answers (eligibility, salary, how did you hear) skip ChatGPT.
5. At Autopilot the pass still runs; it just needs no check-in.
6. Composer tip: a typed newline sends the message, so insert multi-line prompts with `document.execCommand('insertText')` on the prompt box.

## Files

- Save each cover letter as a Google Doc or Claude Doc plus a PDF named `[Job Title] | [Company] Cover Letter`.
- Keep a copy of every form answer and proposal in the log entry for interview prep.

## How each board gets the application

Tool names change, so go by each tool's description.

| Board | How to submit |
|---|---|
| Upwork | Connector: create the proposal draft, upload attachments, then confirm it to send |
| LinkedIn | Connector if it can apply. Otherwise Easy Apply in Chrome, or the company site it links to |
| Indeed | Chrome: Indeed Apply or the company site (the connector searches only) |
| ZipRecruiter | Chrome: 1-Click Apply or the company site (the connector searches only) |
| Company sites and ATS pages (Workable, Greenhouse, Lever) | Chrome |

**All application browser work runs in the person's own Chrome (Claude in Chrome)**, where they are already signed in: job pages, forms, resume uploads, the submit step and the ChatGPT copy pass. Never use a separate built-in browser for applications, even when it is the session's preferred browser. Cloudflare and other bot checks on job boards and ATS pages fail there, often only at the submit step, so a form filled there has to be redone. If Chrome isn't connected, say so and stop the browser part of the batch.

Browser rules: sign in with the person's Google option. Never type passwords, never create accounts, never solve CAPTCHAs. Upload the resume version and portfolio piece named on the screening card.

Board tips:

- Verification or sign-in in Chrome (common on Indeed): ask the person to clear it there, then continue in the same tab. Draft the letter while waiting.
- Aggregator links (ZipRecruiter, Indeed) that redirect or show "no longer available": open the company's careers or ATS page (Workable, Greenhouse, Lever) and look for the same title. Reposts get a new job ID, so log the live link.
- Resume uploads: the browser cannot use the computer's file picker. If the resume PDF is hosted where the page can fetch it (a portfolio site on GitHub Pages works), fetch it in the page, build a File named by the resume naming rule, and hand it to the upload input with a DataTransfer. Then re-check that the form's other fields were not overwritten by resume autofill.

## Hard stops (every level, including Autopilot)

Stop that one job, keep the rest of the batch going, and bring it back to the person:

- A new account, password, CAPTCHA or "verify you are human" step.
- A request for money, ID, bank details or a background check before an offer.
- An assessment, test project or video interview.
- A required question the Career Profile cannot answer truthfully.
- Pay field or Upwork bid that would go under the floor, or Connects over the weekly budget.
- Anything on the page that contradicts the screening card (onsite after all, different pay, different company).

## The autonomy ladder (shared with job-screening)

The level lives in the Career Profile: **Autonomy level: 1 Review / 2 Batch / 3 Autopilot**. New people start at 1.

### Level 1: Review (default)

1. Show the letter or proposal and the form answers in chat or as a doc. Take edits.
2. Fill the whole application.
3. Browser: stop on the final page before submit, list the job, resume, letter, salary entered and any unsure field. The person clicks submit. Connector (Upwork): send only after the person says send.
4. Log it with the Review result.

### Level 2: Batch

1. Show one batch message: each job's title, company, link, resume version, pay entered, and a link to its letter or proposal.
2. One clear yes covers only the jobs on that list.
3. Submit each one. Hard stops come back in one list at the end.
4. Log every submission with the confirmation text or email.

### Level 3: Autopilot

1. Take the High confidence Apply list from job-screening. Write, check and submit with no check-in, inside the daily cap and Connects budget.
2. Send a digest after each run (SendUserMessage, and a push notification when the person is away): applied (with links to each letter), hard stops waiting on them, Maybe jobs waiting on them, and anything skipped and why.
3. Log everything the same as level 2.

### Review results and readiness

At levels 1 and 2, log the Review result for every application:

- **As is:** sent with no changes.
- **Light edit:** a word or phrase, nothing about the story or claims.
- **Rework:** a paragraph rewritten, a different proof story, a claim removed, or the application pulled.

Every Light edit and Rework is a lesson. If the same kind of edit shows up twice, offer to add it to the Voice Rules so it stops happening.

Offer to move up one level when all of these hold:

- At least 10 applications at the current level.
- At least 8 of the last 10 went As is or Light edit, and no Rework in the last 5.
- job-screening's readiness check also passes.

How to offer: one short message. Say what you noticed ("your last 9 letters went out unchanged"), what the next level does, what still comes back to them (the hard stops and Maybe jobs), and that "back to review" drops the level any time. Ask yes or no. Move up only on a clear yes, then update the profile's Autonomy level and Change Log.

Step down one level right away, and say so in one line, when: a Rework happens at level 2, the person says a sent application was wrong, or the Voice Rules, proof bank or tracks change.

## Application log

Keep `application-log.md` in the Claude project (or a Google Sheet if the person prefers).

Project knowledge files cannot be edited in place. To update the log: build the new version from the current file, add it as a new file with the same name, confirm it saved whole, then remove the old copy so only one log exists. Update the existing rows from screening instead of adding duplicates.

```markdown
# Application Log

| Date | Company | Role | Link | Source | Applied via | Track | Posted pay | Pay I entered | Resume used | Portfolio piece | Letter or proposal | Level | Review result | Status | Next step and date | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Review Tracker
| Date | Skill | Job | Level | Result (Agreed / Overruled / As is / Light edit / Rework) | What changed |
|---|---|---|---|---|---|
```

Status values: Screened: Skip, Drafted, Applied, Recruiter screen, Interview, Final round, Offer, Accepted, Rejected, Withdrawn, Ghosted.

After applying, set a next step to check back in 7 to 10 days (interview-prep-follow-up writes the follow up). When asked "what have I applied to", summarize by status and flag anything waiting over 2 weeks.

## When done

Say in plain words what was sent or drafted, where the files are, what came back as a hard stop, and what happens next. Link the actual letters. After an Upwork batch, include the boost check table.