---
name: "job-screening"
description: "Step 4 of the job search skill set. Finds jobs and decides which are worth applying to, checked against the person's Career Profile. Searches Indeed through its connector plus other boards in the browser, then gives each job a screening card: truly remote or not, what the company does, key duties, fit by track, pay check against the money floor, a safe pay number for forms when none is posted, skill gaps, No list conflicts, which resume and portfolio to use, which past role to lead with, and an Apply, Maybe or Skip call. Skips jobs already in the application log. Use for \"find me jobs\", \"check this job post\", \"is this job a good fit\", \"what salary should I put\", \"which resume for this\", \"run my daily job search\", or a pasted job link. Works for any person and field."
---

# Job Screening

Part of a six skill job search set (career-goal-mapping, resume-builder, portfolio-builder, job-screening, application-writer, interview-prep-follow-up).

## Core rule: no long dashes (applies to every person)

This rule is part of the job search skill set and does not change per person. Everything this skill writes follows it: screening cards, ranked job lists, application log entries, and the messages Claude sends the person.

- Never use the em dash (—) or the en dash (–). The plain hyphen (-) is fine inside words like "full-time" or "30-60-90".
- Rewrite instead of swapping one dash for another:
  - Two related ideas become two separate sentences.
  - A label and its detail use a colon ("Pay: $85K to $95K").
  - Side-by-side items, or a title and a name, use a vertical bar ("Designer | Acme Co").
  - Ranges use "to" ("Jan 2024 to Mar 2026", "$78K to $96K").
- Text pulled from job posts, old resumes, templates, ChatGPT or any other tool gets rewritten the same way before it goes into anything this skill makes. Direct quotes from a job post on a screening card are the only exception.
- Before showing, saving or sending anything, search it for "—", "–", "&mdash;", "&ndash;", "&#8212;" and "&#8211;". The count must be zero.

The person's other style preferences (words to avoid, tone, greetings) come from the Voice Rules in their Career Profile and change per person.

## Before you start

1. Read the **Career Profile** (`career-profile.md` in the Claude project). If missing, run **career-goal-mapping** first.
2. Read `application-log.md` so you never screen or apply to the same job twice.

## Mode A: Check one job post

The person pastes a link, a job ID, or the post text.

1. Get the full post. Indeed links or IDs: use the Indeed connector `get_job_details`. Other sites: open in the browser and read the page.
2. Research the company: Indeed connector `get_company_data` (ratings, size, salaries for the job title), the company website, and a quick web search for funding, size, news, and how they talk about AI.
3. Fill the screening card below.

## Mode B: Daily search

1. Use the search settings in the Career Profile (titles, locations, boards, time per board).
2. **Indeed:** connector `search_jobs` for each target title and location ("remote" for remote). Then `get_job_details` on the promising ones.
3. **Other boards** (LinkedIn, ZipRecruiter, Upwork, Wellfound, niche boards): open in the browser, filter to the last 24 hours, read listings. Sign in with the person's Google option if a login is needed. Never type a password and never solve a CAPTCHA. If one appears, ask the person to click through it.
4. Drop anything already in the application log, anything posted over 30 days ago, and anything that hits a hard No.
5. Write a short card for each survivor and a ranked list: Apply first, then Maybe.
6. Offer to send the Apply list to **application-writer**.

## The screening card

Answer every line. Keep it scannable. Follow the core no long dashes rule.

```markdown
## [Job title] | [Company]
Link: [url]  |  Posted: [date]  |  Source: [board]

**Call: Apply / Maybe / Skip** (one sentence why)

1. Remote check: Fully remote / Hybrid / Onsite / Unclear. Quote the line that proves it. Note time zone or travel asks.
2. The company: 2 to 3 lines on what they do and who they serve.
3. Key duties: bullets, each with how it helps the company's customers or goals.
4. Track fit: which track (1, 2, 3, or none) and why.
5. Pay check:
   - Posted: $___ (or "not posted")
   - Yearly or hourly equivalent:
   - Vs survival floor and the track's pay band: above / at / below
   - Safe number for the form: $___ (see pay rules)
   - Number to aim for when talking live: $___
6. Skill gaps: what they want that the person cannot prove yet.
7. Career Path gaps: anything that clashes with the guardrails, Yes list or No list.
8. Red flags: (see list below)
9. Use this resume: [version], tailored? yes/no
10. Lead with this role: [title at company] because ___
11. Feature this portfolio piece: [name + link]
12. Cover letter angle: the one story that best matches their top need.
```

## Pay rules

- Convert everything: hourly x 2,080 = yearly. Yearly / 12 = monthly. Compare with the survival floor.
- **Posted range:** suggest the upper middle of the range for the form. High enough to signal level, not so high that a filter auto rejects it. Example: posted $78K to $96K, put $88K to $92K.
- **No range posted:** research first (Indeed salaries for the title at that company, size, funding, location of HQ), then suggest a number inside what that company plausibly pays.
- **Way under the floor:** call it Skip, or Maybe only if the person said they need fast income. If the real rate turns up later and is far lower than expected, recommend walking away unless it can nearly double, and offer to draft a polite walk-away note (interview-prep-follow-up has the template).
- Keep two numbers separate: the "safe for the form" number and the "aim for live" number.

## Common red flags

- Says remote but asks for office days, a local address, or "onsite for some projects".
- Pay below the floor, or commission only, or "unlimited earning potential" with no base.
- Duties that are on the No list (example: managing people, HR reviews, generalist "do everything" roles).
- Staffing agency posts where the real employer and the real pay are unclear. Ask who the employer of record is.
- Time zone that clashes with the person's guardrails.
- A ban on AI tools, if the person's work relies on them.
- Same post reposted for months, or vague duties with a huge title.
- Requests for bank details, ID, or money before an offer. Treat as a scam and say so plainly.

## Picking the resume and portfolio

- Match the track first, then the job's level: execution roles get the execution version, senior or strategy roles get the senior version, mixed roles get the hybrid version.
- Lead with the role whose duties overlap the post most, even if it is not the most recent.
- Feature one portfolio piece, the one closest to their top duty. A mini case study often beats a big general portfolio.

## When done

Give the cards (or the ranked list) and one plain line on what to do next. Add Skip results to the application log with status "Screened: Skip" so they are not checked again.